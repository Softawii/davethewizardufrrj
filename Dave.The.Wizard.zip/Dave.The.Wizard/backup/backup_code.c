#include <stdio.h> // FUNCOES BASICAS // se necessario
#include <stdbool.h> // BOOLEANAS //
#include <SDL2/SDL.h> //SDL LIBRARY //
#include <SDL2/SDL_image.h>
//VARIAVEIS, SURFACES, ETC//
int w=1920,h=1080;
bool gaming = true; //GAME LOOP//
int gX = 300, gY = 300; //MOVIMENTAÇÃO//
int x, y; //VARIAVEIS EXTRAS//
int gXm = 0, gYm = 0;// MOV MONSTER//
SDL_Window* gJanela = NULL; // CRIANDO JANELA //

SDL_Renderer* render;// Render da Screen //

SDL_Texture* playerTex; //textura do Personagem
SDL_Surface* playerSurf; //Surface do Player

SDL_Texture* monsterTex; //textura do monstro//
SDL_Surface* monsterSurf; //surface do player//

SDL_Event event; //LER EVENTOS//


//CHAMADA//
bool janela (void);
bool surfaces (void);
bool renderizar(void);
bool rescalar(void);
void movements (void);
void makemovements(void);
void mob (void);
// FUNCOES //
                                                                                  //INICIAÇÃO//
bool surfaces (void) {
                                                                      //Gerando Texturas e Sprites do Player//
  //PLAYER SPRITES//
  playerSurf = IMG_Load("sprites/princess.png");
  playerTex = SDL_CreateTextureFromSurface(render, playerSurf);
  SDL_FreeSurface(playerSurf);
  //MONSTER1//
  monsterSurf = IMG_Load("sprites/monster.png");
  monsterTex = SDL_CreateTextureFromSurface(render, monsterSurf);
  SDL_FreeSurface(monsterSurf);
  //WALL//
  //PLAYER SPRITES//
  playerSurf = IMG_Load("sprites/princess.png");
  playerTex = SDL_CreateTextureFromSurface(render, playerSurf);
  SDL_FreeSurface(playerSurf);
}
bool janela (void) {
  bool success = true;
  // START //
  if(SDL_Init(SDL_INIT_VIDEO) < 0) {
    printf("Ocorreu um imprevisto! :(, %s\n", SDL_GetError());
      success = false;
      // A TELA NÃO INICIOU //
  }
  else {
    //VARIAVEIS//
    gJanela = SDL_CreateWindow("NOME DO JOGO", SDL_WINDOWPOS_CENTERED,SDL_WINDOWPOS_CENTERED, w,h, SDL_WINDOW_RESIZABLE);
      if(gJanela == NULL) {
          printf("Ocorreu um imprevisto! :(, %s\n", SDL_GetError()); 
            success = false;
        }
      else{
          render = SDL_CreateRenderer(gJanela, -1, 0);
          SDL_SetRenderDrawColor(render, 217, 172, 37, 255);
        }
  }
  //FIM//
  return success;
}
bool rescalar(void){
   if(event.type ==SDL_WINDOWEVENT)
      if(event.type ==SDL_WINDOWEVENT_RESIZED)
      {
        w=event.window.data1;
        h=event.window.data2;
    }
}
                                                                                              //MOVIMENTOS E RENDER//
void movements (void) {
  // RECONHECER MOVIMENTOS //
  if(event.type == SDL_KEYDOWN) { // Pressionando as teclas //
    if(event.key.keysym.sym == SDLK_LEFT)
        x = 1;
    if(event.key.keysym.sym == SDLK_RIGHT)
        x = -1;
      if(event.key.keysym.sym == SDLK_UP)
        y = 1;
    if(event.key.keysym.sym == SDLK_DOWN)
        y = -1;
  }
  else if(event.type == SDL_KEYUP) { // Despressionando as teclas //
    if(event.key.keysym.sym == SDLK_LEFT)
        x = 0;
    if(event.key.keysym.sym == SDLK_RIGHT)
        x = 0;
    if(event.key.keysym.sym == SDLK_UP)
        y = 0;
    if(event.key.keysym.sym == SDLK_DOWN)
        y = 0; 
  }
}
void makemovements(void) {
  // DANDO MOVIMENTOS //
  if(x == -1 && gX <= 1920-64) // Direita //
    gX += 7;
  if(x == 1 && gX >= 0) // ESQUERDA //
    gX -= 7;
  if(y == -1 && gY <= 1080-120) //  BAIXO //
    gY += 7;
  if(y == 1 && gY >= 0-32) // CIMA //
    gY -= 7; 
}

void mob (void) {
  static int dir = -1, esq = 1;
  if(gXm >= 80) {
    dir = -1;
    esq = 1;
  }
  if(gXm <= -80) {
    dir = 1;
    esq = -1;
  }
  if(dir == 1 && esq == -1)
    gXm += 2;
  if(esq == 1 && dir == -1)
    gXm -= 2;
}
bool renderizar(void) {
  //RECT do Player//
  SDL_Rect sR = {0,0,32,60};
  SDL_Rect rR = {gX, gY, 64,120};
  //RECT do MONSTRO//
  SDL_Rect sRm = {0,0,32,32};
  SDL_Rect rRm = {gXm + 700,gYm + 700,120,120};

  //Renderizar//
  SDL_RenderClear(render);
  //MOVIMENT DO PLAYER//
  SDL_RenderCopy(render, playerTex, &sR, &rR);
  //MOVIMENT DOS MONSTROS//
  SDL_RenderCopy(render, monsterTex, &sRm, &rRm );
  //PRESENT//
  SDL_RenderPresent(render);
}
                                                                                                                      // MAIN // 
int main (void) {
  //INICIANDO SDL//
  SDL_Init(SDL_INIT_EVERYTHING);
  //Start em Window//
  if(!janela()) {
    printf("A TELA NÃO INICIOU!");
  }
  else{
    //GAME HERE//
    surfaces();
    while(gaming) {                                                                                                             //GAME LOOP//
      //Eventos//
      while(SDL_PollEvent(&event)){
        //X to close//
        if (event.type == SDL_QUIT)
          gaming = false;
        //reconhecendo movimentos//
        movements();
      }
      //RESCALAR JANELA E SPRITES
      rescalar();
      SDL_RenderSetLogicalSize(render, 1920, 1080);
      //dando movimentos//
      makemovements();
      //movimentos dos mobs//
      //APRESENTANDO AO USUARIO//
      renderizar();
      mob();
      SDL_Delay(1000/60);
    }
  }
  //Destroy//
  SDL_DestroyWindow(gJanela);
  SDL_DestroyTexture(playerTex);
  SDL_DestroyTexture(monsterTex);
  //FIM//
  SDL_Quit();   
}