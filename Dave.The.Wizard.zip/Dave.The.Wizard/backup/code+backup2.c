#include <stdio.h> // FUNCOES BASICAS // se necessario
#include <stdbool.h> // BOOLEANAS //
#include "SDL2/SDL.h" //SDL LIBRARY //
#include "SDL2/SDL_image.h"
#include "SDL2/SDL_mixer.h"
#include <math.h>
#define LIFE 5
#define LIFEMOB1 2
#define DELAY_PROJETIL 60
#define PROJETILVEL 6

//test//
//VARIAVEIS, SURFACES, ETC//
int sala=1, checkSala = 1;
int w=1600,h=1000;
bool gaming = true; //GAME LOOP//
int gX = 1145, gY = 264; //MOVIMENTAÇÃO//
int x, y; //VARIAVEIS EXTRAS//

//COLISOES//
bool colisao = false;
//MAP//
SDL_Rect rRcam = {0,0,640, 400};
SDL_Texture* mapTex; //textura da wall//
SDL_Surface* mapSurf; //surface da wall//
int mapw = 2560;
int maph = 1200;
//interactives blocks//
SDL_Texture* interactiveTex;
SDL_Surface* interactiveSurf; 
SDL_Rect sCaixa[1] = {0,0,8,12};
SDL_Rect rCaixa[1];
int numPortas = 1;
SDL_Rect sPorta[1] = {9,0,15,12};
SDL_Rect rPorta[1];
int caixax[1] = {950};
int caixay[1] = {200};
bool porta[1] = {true};
//WALL//
SDL_Rect rRw[19];
SDL_Texture* wallTex; //textura da wall//
SDL_Surface* wallSurf; //surface da wall//
int numWall = 19;

//MONSTER-SLIME//
SDL_Rect rRm[8];
SDL_Texture* monsterTex; //textura do monstro//
SDL_Surface* monsterSurf; //surface do player//
SDL_Texture* monsterTex2; //textura do monstro red//
SDL_Surface* monsterSurf2; //surface do player red//
int rngx = 28;
int rngy = 19;
int andando[8] = {1, -1, 1, -1, 1, -1, 1, -1};
int lifemob[8] = {LIFEMOB1, LIFEMOB1, LIFEMOB1, LIFEMOB1, LIFEMOB1, LIFEMOB1, LIFEMOB1, LIFEMOB1};
int tempAndando[8] = {0}, idAndando;
int mobwaiting = 0;
int maxmobwaiting = 120;
int numMobs = 8;
SDL_Rect sRm = {1, 0, 28, 19};
int lixo = 0; //trash//
int gXm[8] = {0, 0, 0, 0, 0, 0, 0, 0};// MOV MONSTER// 
int gYm[8] = {0, 20, 30, 40, 0, 0, 0, 0};// MOV MONSTER//
int gXmi[8] = {0, 20, 30, 40, 0, 0, 0, 0};// MOV INICIAL MONSTER// 
int gXmv[8] = {2, 2, 2, 2, 2, 2, 2, 2};// VEL INICIAL MONSTER// 
int gXmr[8] = {50, 80, 120, 50, 90, 90, 90, 90};// RANGE MONSTER// 
// de 0 a 3 mobs que nao seguem // 4 a 8 kill//
bool perseguir[8] = {false, false, false, false, true, true, true, true};


//PLAYER//
SDL_Rect rR;
SDL_Rect sR;
SDL_Texture* playerTex; //textura do Personagem
SDL_Surface* playerSurf; //Surface do Player
SDL_Texture* objectTex; //textura de objtos//
SDL_Surface* objectSurf; // surface de objetos//
int life = LIFE; //VIDA DO PLAYER//
int invencible = 0; //INVENCIBILIDADE DE DANO//
int kback = 0; //knockback//
int kbacktime = 0; //knockback time//
int const vel = 2; // VELOCIDADE DO PLAYER //
char sentido = 'b';
bool cajado = false; //se esta equipando o cajado magico topzudo//
bool interagir = false; // se estamos interagindo com algum item maneiro //
  //cajado//
bool projetil = false;
SDL_Rect rProjetil; /*{-50,-50,14,14}*/
SDL_Rect sProjetil;
SDL_Rect rProjetilPoder = {640-84, 2, 42, 43.5};
SDL_Rect sProjetilPoder = {0, 0, 28, 29};
SDL_Rect siconCajado = {0,0,16,16};
SDL_Rect riconCajado;
//hud//
SDL_Rect rH; //rect HUD//
SDL_Texture* heartTex; //textura do Personagem
SDL_Surface* heartSurf; //Surface do Player
SDL_Texture* HUDTex; // textura dos huds*//
SDL_Surface* HUDSurf; // surface dos huds//  

SDL_Surface* fadeSurf;//fade in-out surface//
SDL_Texture* fadeTex;
int fadeAlpha = 0;

SDL_Window* gJanela = NULL; // CRIANDO JANELA //

SDL_Renderer* render;// Render da Screen //

SDL_Event event; //LER EVENTOS//

//AUDIO//
Mix_Chunk* damage;
Mix_Chunk* death;
Mix_Chunk* hitwall;
Mix_Chunk* welcome;
Mix_Chunk* projetilhit;
Mix_Chunk* projetilstart;
Mix_Chunk* projetilend;
Mix_Chunk* walk;
Mix_Chunk* warning;
Mix_Music* fightmusic;

//CHAMADA//
bool janela (void);
void surfaces (void);
bool renderizar(void);
bool rescalar(void);
void movements (void);
void makemovements(void);
void teladeAnimacaoIN (void);
void teladeAnimacaoOUT (void);
int mob (int i, bool colid, SDL_Rect r1);
void teladeAnimacao (void);
bool collision(SDL_Rect r1, SDL_Rect r2, int velocidadex, int velocidadey);
void salaCamera();
void salaAtual();
void slimeAnimated(int i);
void interaction(void);
void blocksinteractive(void);
void verificator(void);
// FUNCOES //
                                                                               //INICIAÇÃO//
void audio(void) {
  damage = Mix_LoadWAV("sfx/damage.wav");
  death = Mix_LoadWAV("sfx/death.wav");
  hitwall = Mix_LoadWAV("sfx/hitwall.wav");
  welcome = Mix_LoadWAV("sfx/welcome.wav");
  projetilhit = Mix_LoadWAV("sfx/projetilhit.wav");
  projetilstart = Mix_LoadWAV("sfx/projetilstart.wav");
  projetilend = Mix_LoadWAV("sfx/projetilend.wav");
  walk = Mix_LoadWAV("sfx/walk.wav");
  warning = Mix_LoadWAV("sfx/warning.wav");
  fightmusic = Mix_LoadMUS("songs/fight.mp3");
}
void surfaces (void) {
                                                                   //Gerando Texturas e Sprites do Player//
  //PLAYER SPRITES//
  playerSurf = IMG_Load("sprites/char.png");
  playerTex = SDL_CreateTextureFromSurface(render, playerSurf);
  SDL_FreeSurface(playerSurf);
  //MONSTER1//
  monsterSurf = IMG_Load("sprites/monster.png");
  monsterTex = SDL_CreateTextureFromSurface(render, monsterSurf);
  SDL_FreeSurface(monsterSurf);
  //MONSTER2//
  monsterSurf2 = IMG_Load("sprites/monsterred.png");
  monsterTex2 = SDL_CreateTextureFromSurface(render, monsterSurf2);
  SDL_FreeSurface(monsterSurf2);
  //WALL//
  wallSurf = IMG_Load("sprites/wall.png");
  wallTex = SDL_CreateTextureFromSurface(render, wallSurf);
  SDL_FreeSurface(wallSurf);
  //MAP//
  mapSurf = IMG_Load("img/world.png");
  mapTex = SDL_CreateTextureFromSurface(render, mapSurf);
  SDL_QueryTexture(mapTex, NULL, NULL, &mapw, &maph);
  SDL_FreeSurface(mapSurf);
  //HEART//
  heartSurf = IMG_Load("sprites/hud_heart.png");
  heartTex = SDL_CreateTextureFromSurface(render, heartSurf);
  SDL_FreeSurface(heartSurf);
  //FADE//
  fadeSurf = IMG_Load("img/fade.png");
  fadeTex = SDL_CreateTextureFromSurface(render, fadeSurf);
  SDL_FreeSurface(fadeSurf);
  //OBJETOS//
  objectSurf = IMG_Load("sprites/objetos.png");
  objectTex = SDL_CreateTextureFromSurface(render, objectSurf);
  SDL_FreeSurface(objectSurf);
  //HUD ITENS//
  HUDSurf = IMG_Load("sprites/icon.png");
  HUDTex = SDL_CreateTextureFromSurface(render, HUDSurf);
  SDL_FreeSurface(HUDSurf);
  //OBJETOS INTERATIVOS//
  interactiveSurf = IMG_Load("sprites/interactive.png");
  interactiveTex = SDL_CreateTextureFromSurface(render, interactiveSurf);
  SDL_FreeSurface(interactiveSurf);
}
bool janela (void) {
  bool success = true;
  // START //
  if(SDL_Init(SDL_INIT_VIDEO) < 0) {
    printf("Ocorreu um imprevisto! :(, %s\n", SDL_GetError());
      success = false;
      // A TELA NÃO INICIOU //
  }
  else {
    printf("[Console]SDL iniciado!\n");
    SDL_Delay(100);
    //VARIAVEIS//
    gJanela = SDL_CreateWindow("Dave, The Wizard!", SDL_WINDOWPOS_CENTERED,SDL_WINDOWPOS_CENTERED, w,h, SDL_WINDOW_RESIZABLE);
      if(gJanela == NULL) {
          printf("Ocorreu um imprevisto! :(, %s\n", SDL_GetError()); 
            success = false;
        }
      else{
          render = SDL_CreateRenderer(gJanela, -1, 0);
          SDL_SetRenderDrawColor(render, 0, 0, 0, 255);
        }
  }
  //FIM//
  return success;
}
bool rescalar(void){
   if(event.type ==SDL_WINDOWEVENT)
      if(event.type ==SDL_WINDOWEVENT_RESIZED)
      {
        w=event.window.data1;
        h=event.window.data2;
    }
}
                                                                                              //MOVIMENTOS E RENDER//
void movements (void) {
  // RECONHECER MOVIMENTOS //
  if(event.type == SDL_KEYDOWN && kbacktime == 0 && !projetil) { // Pressionando as teclas //
    if(event.key.keysym.sym == SDLK_LEFT) {
        x = -1;
        sentido = 'e';
    }
    if(event.key.keysym.sym == SDLK_RIGHT) {
        x = 1;
        sentido = 'd';
    }
    if(event.key.keysym.sym == SDLK_UP) {
        y = -1;
        sentido = 'c';
    }
    if(event.key.keysym.sym == SDLK_DOWN) {
        y = 1;
        sentido = 'b';
    }
    //atirar projetil//
    if(event.key.keysym.sym == SDLK_z) {
        projetil = true;
    }
    //interagir//
    if(event.key.keysym.sym == SDLK_LALT) {
      interagir = true;
    }
  }
  if(event.type == SDL_KEYUP) { // Despressionando as teclas //
    if(event.key.keysym.sym == SDLK_LEFT)
        x = 0;
    if(event.key.keysym.sym == SDLK_RIGHT)
        x = 0;
    if(event.key.keysym.sym == SDLK_UP)
        y = 0;
    if(event.key.keysym.sym == SDLK_DOWN)
        y = 0; 
    if(event.key.keysym.sym == SDLK_z) {
        projetil = false;
    }
    if(event.key.keysym.sym == SDLK_LALT) {
      interagir = false;
    }
  }
}
void makemovements(void) {
  // DANDO MOVIMENTOS //
  if(/*!colisao &&*/ kbacktime == 0 && !projetil) {  
    if(x == 1) { // Direita //
      //colisao com paredes//
      for(int i = 0; i < numWall && !colisao; i++) { //COLIDINDO COM WALL//
        colisao = collision(rR, rRw[i], vel, 0);
      }
      //colisao com portas//
      if(!colisao) {
        for(int i = 0; i < numPortas && !colisao; i++)
          colisao = collision(rR, rPorta[0], vel, 0);
      }
      if(!colisao)
          gX += vel;
      colisao = false;
    }
    if(x == -1) { // ESQUERDA //
      for(int i = 0; i < numWall && !colisao; i++) { //COLIDINDO COM WALL//
        colisao = collision(rR, rRw[i], -vel, 0);
      }
      if(!colisao) {
        for(int i = 0; i < numPortas && !colisao; i++)
          colisao = collision(rR, rPorta[0], -vel, 0);
      }
      if(!colisao)
          gX -= vel;
      colisao = false;
    }
    if(y == 1) { //  BAIXO //
      for(int i = 0; i < numWall && !colisao; i++) { //COLIDINDO COM WALL//
        colisao = collision(rR, rRw[i], 0, vel);
      }
      if(!colisao) {
        for(int i = 0; i < numPortas && !colisao; i++)
          colisao = collision(rR, rPorta[0], 0, vel);
      }
      if(!colisao)
          gY += vel;
      colisao = false;
    }
    if(y == -1) { // CIMA //
      for(int i = 0; i < numWall && !colisao; i++) { //COLIDINDO COM WALL//
        colisao = collision(rR, rRw[i], 0, -vel);
      }
      if(!colisao) {
        for(int i = 0; i < numPortas && !colisao; i++)
          colisao = collision(rR, rPorta[0], 0, -vel);
      }
      if(!colisao)
          gY -= vel;
      colisao = false; 
    }
  }
}
bool collision(SDL_Rect r1, SDL_Rect r2, int velocidadex, int velocidadey) {
  r1.x += velocidadex;
  r1.y += velocidadey;
  if( r1.x + r1.w > r2.x && r2.x + r2.w > r1.x &&
    r1.y + r1.h > r2.y && r2.y + r2.h > r1.y) {
    return true;
  }
  return false;
}
int mob (int i, bool colid, SDL_Rect r1) { 
  static int distancia = 200;
  static int direct;
  static bool hostil = false;
  static bool dir = false, esq = false, cim = false, baix = false;
  hostil = false;
  colisao = false;
  dir = false; esq = false; cim = false; baix = false;
  //verificador de colisoes//
  //parede//
  colisao = false;
  for(int w = 0; w < numWall && !colisao; w++) {
    if(lifemob[i] > 0) {  
      //colisao x direita//
      colisao = collision(rRm[i], rRw[w], gXmv[i], 0);
      if(colisao) {
        dir = true;
        andando[i] *= -1;
      }
      //colisao x esquerda//
      colisao = collision(rRm[i], rRw[w], -gXmv[i], 0);
      if(colisao) {
        esq = true;
        andando[i] *= -1;
      }
      //colisao y cima//
      colisao = collision(rRm[i], rRw[w], 0, -gXmv[i]);
      if(colisao) {
        cim = true;
        andando[i] *= -1;
      }
      colisao = collision(rRm[i], rRw[w], 0, gXmv[i]);
      if(colisao) {
        baix = true;
        andando[i] *= -1;
      }
    }
  }
  colisao = false;
  //mob
  for(int w = 0; w < numMobs && !colisao; w++) {
    if(w != i && lifemob[w] > 0 && lifemob[i] > 0) {
      colisao = collision(rRm[i], rRm[w], 0, 0);
      if(colisao) {
        if(rRm[i].x + rRm[i].w - rRm[w].x < 0) {
          gXm[i] += 10;
          gXm[w] -= 10;
        }
      }
    }
  }
  //end//
  // perseguir //
  if(invencible == 0 && lifemob[i] > 0 && !colisao) {
    if(sqrt(pow(rR.x + rR.w - rRm[i].x,2) +pow(rR.y + rR.h -rRm[i].y,2)) <= distancia && perseguir[i]) {
      //printf(" -- %f %i \n\n", dist, i ); print para debug
      //olhando para x//
      hostil = true;
      if(rR.x - rRm[i].x + rRm[i].w < 5 && !esq && !colisao) {
        gXm[i] -= 7*gXmv[i]/8;
        direct = -1;
      }
      else if(rR.x - rRm[i].x + rRm[i].w > -5 && !dir && !colisao) {
        gXm[i] += 7*gXmv[i]/8;
        direct = 1;
      }
      //olhando para y//
      if(rR.y - rRm[i].y + rRm[i].h < 0 && !cim && !colisao){
        gYm[i] -= 7*gXmv[i]/8;
      }
      else if(rR.y - rRm[i].y + rRm[i].h > 0 && !baix && !colisao){
        gYm[i] += 7*gXmv[i]/8;
      }
    }
    if(hostil)
      return direct;
  }
  if(lifemob[i] > 0 && !hostil && !colisao) {
    if(gXm[i] >= gXmi[i] + gXmr[i]) {
      andando[i] = -1;
    }
    else if(gXm[i] <= gXmi[i] - gXmr[i]) {
      andando[i] = 1;
    }
    if(andando[i] == 1 && !dir)
      gXm[i] += gXmv[i];
    else if(andando[i] == -1 && !esq)
      gXm[i] -= gXmv[i];
    return andando[i];
  }
}
void playerAnimated(void /*config*/) {
  //RECT do Player//
  static int move = 0;
  static int contador = 1;
  //SEM DANO//
  if(!cajado) {  //SEM CAJADO//
    if(y == -1 && kbacktime == 0) {
      //FRENTE//
      if(contador >= 0 && contador <= 8)
        move = 0;
      else if(contador > 8 && contador <= 16)
        move = 1;
      else if(contador > 16 && contador <= 24)
        move = 2;
      else if(contador > 24 && contador <= 32)
        move = 3;
      else if(contador > 32) {
        move = 0;
        contador = 0;
      }
      sR.x = 4 + 24*move; sR.y = 70; sR.w = 16; sR.h = 25;
      if(invencible > 0) {
        sR.x = 100 + 24*move;
      }
    }
    //COSTAS//
    else if(y == 1 && kbacktime == 0) {
      if(contador >= 0 && contador <= 8)
        move = 0;
      else if(contador > 8 && contador <= 16)
        move = 1;
      else if(contador > 16 && contador <= 24)
        move = 2;
      else if(contador > 24 && contador <= 32)
        move = 3;
      else if(contador > 32) {
        move = 0;
        contador = 0;
      }
      sR.x = 4 + 24*move; sR.y = 6; sR.w = 16; sR.h = 25;
      if(invencible > 0) {
        sR.x = 100 + 24*move;
      }
    }
    //LADO DIREITO//
    else if(x == 1 && kbacktime == 0) {
      if(contador >= 0 && contador <= 16)
        move = 0;
      else if(contador > 16 && contador <= 32)
        move = 1;
      else if(contador > 32) {
        move = 0;
        contador = 0;
      }
      sR.x = 53 + 23*move; sR.y = 38; sR.w = 16; sR.h = 25;
      if(invencible > 0) {
        sR.x = 149 + 24*move;
      }
    }
    //LADO ESQUERDO//
    else if(x == -1 && kbacktime == 0) {
      if(contador >= 0 && contador <= 16)
        move = 0;
      else if(contador > 16 && contador <= 32)
        move = 1;
      else if(contador > 32) {
        move = 0;
        contador = 0;
      }
      sR.x = 5 + 24*move; sR.y = 38; sR.w = 16; sR.h = 25;
      if(invencible > 0) {
        sR.x = 101 + 24*move;
      }
    }
    else {
      if(contador >= 0 && contador <= 32)
        move = 0;
      else if(contador > 32) {
        move = 0;
        contador = 0;
      }
      if(sentido == 'b') {
        sR.x = 4; sR.y = 6; sR.w = 16; sR.h = 25;
        if(invencible > 0) {
          sR.x = 100;
        }
      }
      else if(sentido == 'c') {
        sR.x = 4 + 24*move; sR.y = 70; sR.w = 16; sR.h = 25;
        if(invencible > 0) {
          sR.x = 100 + 24*move;
        }
      }
      else if(sentido == 'd') {
        sR.x = 53 + 23*move; sR.y = 38; sR.w = 16; sR.h = 25;
        if(invencible > 0) {
          sR.x = 149 + 24*move;
        }
      }
      else if(sentido == 'e') {
        sR.x = 5 + 24*move; sR.y = 38; sR.w = 16; sR.h = 25;
        if(invencible > 0) {
          sR.x = 101 + 24*move;
        }
      }
    }
    rR.x = gX - rRcam.x; rR.y = gY - rRcam.y; rR.w = 24; rR.h = 37.5;
  }
  //com cajado//
  if(cajado) {  //com CAJADO//
    if(y == -1 && kbacktime == 0) {
      //FRENTE//
      if(contador >= 0 && contador <= 8)
        move = 0;
      else if(contador > 8 && contador <= 16)
        move = 1;
      else if(contador > 16 && contador <= 24)
        move = 2;
      else if(contador > 24 && contador <= 32)
        move = 3;
      else if(contador > 32) {
        move = 0;
        contador = 0;
      }
      sR.x = 0 + 20*move; sR.y = 146; sR.w = 17; sR.h = 25;
      if(invencible > 0) {
        sR.x = 100 + 24*move; sR.y = 70; sR.w = 16; sR.h = 25;
      }
    }
    //COSTAS//
    else if(y == 1 && kbacktime == 0) {
      if(contador >= 0 && contador <= 8)
        move = 0;
      else if(contador > 8 && contador <= 16)
        move = 1;
      else if(contador > 16 && contador <= 24)
        move = 2;
      else if(contador > 24 && contador <= 32)
        move = 3;
      else if(contador > 32) {
        move = 0;
        contador = 0;
      }
      sR.x = 0 + 20*move; sR.y = 121; sR.w = 17; sR.h = 25;
      if(invencible > 0) {
        sR.x = 100 + 24*move; sR.y = 6; sR.w = 16; sR.h = 25;
      }
    }
    //LADO DIREITO//
    else if(x == 1 && kbacktime == 0) {
      if(contador >= 0 && contador <= 16)
        move = 0;
      else if(contador > 16 && contador <= 32)
        move = 1;
      else if(contador > 32) {
        move = 0;
        contador = 0;
      }
      sR.x = 60 + 20*move; sR.y = 96; sR.w = 17; sR.h = 25;
      if(invencible > 0) {
       sR.x = 149 + 24*move; sR.y = 38; sR.w = 16; sR.h = 25;
       
      }
    }
    //LADO ESQUERDO//
    else if(x == -1 && kbacktime == 0) {
      if(contador >= 0 && contador <= 16)
        move = 0;
      else if(contador > 16 && contador <= 32)
        move = 1;
      else if(contador > 32) {
        move = 0;
        contador = 0;
      }
      sR.x = 3 + 20*move; sR.y = 96; sR.w = 17; sR.h = 25;
      if(invencible > 0) {
        sR.x = 101 + 24*move; sR.y = 38; sR.w = 16; sR.h = 25;

      }
    }
    else {
      if(contador >= 0 && contador <= 32)
        move = 0;
      else if(contador > 32) {
        move = 0;
        contador = 0;
      }
      if(sentido == 'b') {
        sR.x = 0; sR.y = 121; sR.w = 17; sR.h = 25;
        if(invencible > 0) {
        sR.x = 100 + 24*move; sR.y = 6; sR.w = 16; sR.h = 25;
        }
      }
      else if(sentido == 'c') {
        sR.x =  0 + 24*move; sR.y = 146; sR.w = 17; sR.h = 25;
        if(invencible > 0) {
          sR.x = 100 + 24*move;
           sR.x = 100 + 24*move; sR.y = 70; sR.w = 16; sR.h = 25;
        }
      }
      else if(sentido == 'd') {
        sR.x =  60+ 23*move; sR.y = 96; sR.w = 17; sR.h = 25;
        if(invencible > 0) {
        sR.x = 149 + 24*move; sR.y = 38; sR.w = 16; sR.h = 25;
       
        }
      }
      else if(sentido == 'e') {
        sR.x = 3 + 24*move; sR.y = 96; sR.w = 17; sR.h = 25;
        if(invencible > 0) {
          sR.x = 101 + 24*move;sR.y = 38; sR.w = 16; sR.h = 25;
        }
      }
    }
    rR.x = gX - rRcam.x; rR.y = gY - rRcam.y; rR.w = 25.5; rR.h = 37.5;
  }
  if((contador == 0) && (x != 0 || y != 0)) {
     Mix_PlayChannel(2, walk, 0);
  }
  if(fadeAlpha==0)
    contador++;

  //projetil de magia//
  SDL_RenderCopy(render, playerTex, &sProjetil, &rProjetil);
  //MOVIMENT DO PLAYER//;
  SDL_RenderCopy(render, playerTex, &sR, &rR);
}

bool renderizar(void) {
  //RECT CAMERA//
   if(rRcam.x < 0) {
    rRcam.x = 0;
  }
  if(rRcam.y < 0){
    rRcam.y = 0;
  }
  if(rRcam.x + rRcam.w >= mapw) {
    rRcam.x = mapw - 640;
  }
  if(rRcam.y + rRcam.h >= maph) {
    rRcam.y = maph - 400;
  } 
  // HUD configs //
      //heart//
  SDL_Rect sH = {0,11 * life,43,11};
  rH.x = 10; rH.y = 10; rH.w = 86 ;rH.h = 22;
  
  //RECT do Wall//
  SDL_Rect sRw = {0,0,32,32};
  rRw[0].x = 0 - rRcam.x; rRw[0].y = 0 - rRcam.y; rRw[0].w = 740; rRw[0].h = 10; //WALL CANTO ESQUERDO = SALA 1 //
  rRw[1].x = -2 - rRcam.x; rRw[1].y = 40 - rRcam.y; rRw[1].w = 12; rRw[1].h = 360; // WALL CANTO DIREITO = SALA 1 //
  rRw[2].x = -7 - rRcam.x; rRw[2].y = 368 - rRcam.y; rRw[2].w = 103; rRw[2].h = 32; // WALL CIMA = SALA 1//
  rRw[3].x = 159 - rRcam.x; rRw[3].y = 368 - rRcam.y; rRw[3].w = 495; rRw[3].h = 32; // WALL BAIXO  = SALA 1//
  rRw[4].x = 628 - rRcam.x; rRw[4].y = 92 - rRcam.y; rRw[4].w = 111; rRw[4].h = 320; // SALA 1- 2 // 
  rRw[5].x = 747 - rRcam.x; rRw[5].y = 0 - rRcam.y; rRw[5].w = 355; rRw[5].h = 10; // SALA 1- 2 //  
  rRw[6].x = 1071 - rRcam.x; rRw[6].y = 0 - rRcam.y; rRw[6].w = 101; rRw[6].h = 261; // SALA 1- 2 //  
  rRw[7].x = 1071 - rRcam.x; rRw[7].y = 311 - rRcam.y; rRw[7].w = 104; rRw[7].h = 53; // SALA 1- 2 //  
  rRw[8].x = 728 - rRcam.x; rRw[8].y = 330 - rRcam.y; rRw[8].w = 355; rRw[8].h = 35; // SALA 1- 2 //  
  rRw[9].x = 0 - rRcam.x; rRw[9].y = 0 - rRcam.y; rRw[9].w = 0; rRw[9].h = 0; // SALA 1- 2 //  
  rRw[10].x = 731 - rRcam.x; rRw[10].y = 150 - rRcam.y; rRw[10].w = 159; rRw[10].h = 10; // SALA 1- 2 // 
  rRw[11].x = 880 - rRcam.x; rRw[11].y = 51 - rRcam.y; rRw[11].w = 10; rRw[11].h = 108; // SALA 1- 2 // 
  rRw[12].x = 922 - rRcam.x; rRw[12].y = 51 - rRcam.y; rRw[12].w = 10; rRw[12].h = 108; // SALA 1- 2 // 
  rRw[13].x = 922 - rRcam.x; rRw[13].y = 150 - rRcam.y; rRw[13].w = 158; rRw[13].h = 10; // SALA 1- 2 // 
  rRw[14].x = 740 - rRcam.x; rRw[14].y = 180 - rRcam.y; rRw[14].w = 32; rRw[14].h = 48; // caixotes = sala 2 // 
  rRw[15].x = 793 - rRcam.x; rRw[15].y = 180 - rRcam.y; rRw[15].w = 32; rRw[15].h = 48; // caixotes = sala 2// 
  rRw[16].x = 744 - rRcam.x; rRw[16].y = 222 - rRcam.y; rRw[16].w = 16; rRw[16].h = 24; // caixotes = sala 2// 
  rRw[17].x = 798 - rRcam.x; rRw[17].y = 220 - rRcam.y; rRw[17].w = 16; rRw[17].h = 26; // caixotes = sala 2//
  rRw[18].x = 826 - rRcam.x; rRw[18].y = 202 - rRcam.y; rRw[18].w = 16; rRw[18].h = 24; // caixotes = sala 2// 

  
  //Renderizar mapas e acoes//
  SDL_RenderClear(render);
  //MAPA//
  SDL_RenderCopy(render, mapTex, &rRcam, NULL);
  //objetos//
  //rect dos objetos//
  //cajado//
  if(!cajado) {
    riconCajado.x = 1105 - rRcam.x; riconCajado.y = 287 - rRcam.y; riconCajado.w = 16; riconCajado.h = 16;
    SDL_RenderCopy(render, objectTex, &siconCajado, &riconCajado); 
  }
  //MOVIMENT DOS MONSTROS//
  for(int i = 0; i < numMobs; i++) {
    if(lifemob[i] >= 1)
      slimeAnimated(i);
  }
  //RENDER DO WALL//
  for(int i = 0; i < numWall; i++)
    SDL_RenderCopy(render, wallTex, &sRw, &rRw[i]);
  //MOVIMENT DO PLAYER//
  playerAnimated();
  blocksinteractive();
  //HUD//
  SDL_RenderCopy(render, heartTex, &sH, &rH);
  if(cajado) {
    SDL_RenderCopy(render, HUDTex, &sProjetilPoder, &rProjetilPoder);
  }
}
void invencibleF (void) {
  //INVENCIBILIDADE DO JOGADOR APOS A COLISAO COM MOB//
  if(invencible == 1) {
    printf("[Console]Tempo de Invencibilidade Iniciado! %i Vidas!\n", life);
    invencible++;
  }
  else if(invencible > 1 && invencible <= 40) {
    invencible++;
  }
  else if(invencible > 40) {
    invencible = 0; 
    printf("[Console]Tempo de Invencibilidade Finalizado!\n");
  }
}
void knockb(void) {
  //colisao direita//
  if(kback == 1) /*direita*/ {
    printf("[Console]O Jogador foi atirado para direita!\n");
    kbacktime = 1;
    mobwaiting = 1;
    kback = 0;
  }
  if(kbacktime > 0 && kbacktime <= 15) {
    for(int i = 0; i < numWall && !colisao; i++) { //COLIDINDO COM WALL//
      colisao = collision(rR, rRw[i], vel, 0);
    }
    if(!colisao)
      gX += vel;
    kbacktime++;
  }
  if(kbacktime > 15) {
    kbacktime = 0;
    printf("[Console]O Jogador deixou de ser atirado para direita!\n");
  }
  //colisao esquerda//
  if(kback == -1) /*direita*/ {
  printf("[Console]O Jogador foi atirado para esquerda!\n");
    kbacktime = -1;
    mobwaiting = 1;
    kback = 0;
  }
  else if(kbacktime < 0 && kbacktime >= -15) {
    for(int i = 0; i < numWall && !colisao; i++) { //COLIDINDO COM WALL//
      colisao = collision(rR, rRw[i], -vel, 0);
    }
    if(!colisao)
      gX -= vel;
    kbacktime--;
  }
  else if(kbacktime < -15) {
    kbacktime = 0;
    printf("[Console]O Jogador deixou de ser atirado para esquerda!\n");
  }
  //MOBWAITING// 
  if(mobwaiting > 0 && mobwaiting <= maxmobwaiting){
    mobwaiting++;
  }
}
                                                                                                  //CAMERA E IDENTIFICACAO DE SALAS//

void salaAtual()
{
  if(gX >= 0 && gX+rR.w <= 1280 && gY >= 0 && gY+rR.h <= 400) {
    sala = 1;//primeira sala
    if(checkSala != sala) {
      renderizar();
      teladeAnimacaoOUT();
      salaCamera();
      teladeAnimacaoIN();
    }
    checkSala = sala;
  }
  else if(gX >= 0 && gX <= 640 && gY <= 800 && gY > 400) {
    sala = 2;//quarto
    if(checkSala != sala) {
      renderizar();
      teladeAnimacaoOUT();
      salaCamera();
      teladeAnimacaoIN();
    }
    checkSala = sala;
  }
  else if(gX <= 2560 && gX > 1280 && gY >= 0 && gY <= 800) {
    sala = 3;//verdao
    if(checkSala != sala) {
      renderizar();
      teladeAnimacaoOUT();
      salaCamera();
      teladeAnimacaoIN();
    } 
    checkSala = sala;
  }
}
void salaCamera()
{
  if(sala==1)
  {
    rRcam.x=gX-320;
    rRcam.y=0;
    if(rRcam.x>640)
    {
      rRcam.x=640;
    }
  }
  else if(sala==2)
  {
    rRcam.x=0;
    rRcam.y=400;
  }
  else if(sala==3)
  {
    rRcam.x=gX - 320;
    rRcam.y=gY - 200;
    if(rRcam.x < 1280)
      rRcam.x = 1280;
    if(rRcam.y < 0)
      rRcam.y = 0;
    if(rRcam.x + rRcam.w >= 2560)
      rRcam.x = 2560 - 640;
    if(rRcam.y + rRcam.h >= 800)
      rRcam.y= 800 -400;
  }
}
void teladeAnimacaoOUT (void) {
  for(fadeAlpha = 0; fadeAlpha <= 255; fadeAlpha+=5) {
    renderizar();
    SDL_SetTextureAlphaMod(fadeTex, fadeAlpha);
    SDL_RenderCopy(render, fadeTex, NULL, NULL);
    SDL_RenderPresent(render);
    SDL_Delay(7);
  }
}
void teladeAnimacaoIN (void) {
  for(fadeAlpha = 255; fadeAlpha >= 0; fadeAlpha-=5) {
    renderizar();
    SDL_SetTextureAlphaMod(fadeTex, fadeAlpha);
    SDL_RenderCopy(render, fadeTex, NULL, NULL);
    SDL_RenderPresent(render);
    SDL_Delay(7);
  }
  fadeAlpha=0;
}
void projetilF (void) {
  //SDL_Rect rProjetil;
  //SDL_Rect sProjetil;
  static int contador = 0;
  static char sentidop = 'n';
  static int posx, posy;
  static int velprojetil = 6;
  static bool stop = false;
  if(cajado) {
    if(projetil) {
      if(contador == 0) {
        contador = 1;
        posx = gX;
        posy = gY;
        if(sentido == 'e') {
           sentidop = 'e';
           sProjetil.x = 98; sProjetil.y = 139; sProjetil.w = 14; sProjetil.h = 5;
           rProjetil.x = posx-rRcam.x; rProjetil.y = posy+14-rRcam.y; rProjetil.w = 21; rProjetil.h = 7.5;
        }
        else if(sentido == 'd'){
           sProjetil.x = 98; sProjetil.y = 131; sProjetil.w = 14; sProjetil.h = 5;
           rProjetil.x = posx-rRcam.x; rProjetil.y = posy+14-rRcam.y; rProjetil.w = 21; rProjetil.h = 7.5;
           sentidop = 'd';
        }
        else if(sentido == 'c'){
           sentidop = 'c';
          sProjetil.x=99; sProjetil.y=146;sProjetil.w=5; sProjetil.h=14;
          rProjetil.x = posx-rRcam.x; rProjetil.y = posy+14-rRcam.y; rProjetil.w = 7.5; rProjetil.h = 21; 
        }
        else if(sentido == 'b'){
           sentidop = 'b';
           sProjetil.x=107; sProjetil.y=146;sProjetil.w=5; sProjetil.h=14;
          rProjetil.x = posx-rRcam.x; rProjetil.y = posy+14-rRcam.y; rProjetil.w = 7.5; rProjetil.h = 21;
          
        }
        //printf("[Console]projetil lancado para %c\n", sentidop);
      }
    }
    if(contador == 1) { //som do projetil//
      Mix_PlayChannel(3, projetilstart, 0);
    }
    if(contador > 0 && contador <= 45 && !colisao && !stop) {
      //COLISAO DE PROJETIL COM MOBS//
      for(int i = 0; i < numMobs && !colisao; i++) { 
          if(lifemob[i] > 0) { 
            if(sentidop == 'e')
              colisao = collision(rProjetil, rRm[i], -PROJETILVEL, 0);
            else if(sentidop == 'd')
              colisao = collision(rProjetil, rRm[i], PROJETILVEL, 0);
            else if(sentidop == 'c')
              colisao = collision(rProjetil, rRm[i], 0, -PROJETILVEL);
            else if(sentidop == 'b')
              colisao = collision(rProjetil, rRm[i], 0, PROJETILVEL);
            if(colisao) {
              lifemob[i] -= 1;
              Mix_PlayChannel(3, projetilhit, 0);
              printf("[Console]O projetil colidiu com o Mob %i e agora ele tem %i vidas!\n", i, lifemob[i]);
              stop = true;
            }
          }
      } 
      //COLISAO DE PROJETIL COM PAREDE//
      for(int i = 0; i < numWall && !colisao; i++) { 
          if(sentidop == 'e')
            colisao = collision(rProjetil, rRw[i], -PROJETILVEL, 0);
          else if(sentidop == 'd')
            colisao = collision(rProjetil, rRw[i], PROJETILVEL, 0);
          else if(sentidop == 'c')
            colisao = collision(rProjetil, rRw[i], 0, -PROJETILVEL);
          else if(sentidop == 'b')
            colisao = collision(rProjetil, rRw[i], 0, PROJETILVEL);
          if(colisao) {
            printf("[Console]O projetil colidiu com a parede %i\n", i); 
            stop = true;        
        }
      } 
      if(sentidop == 'e') {
        rProjetil.x = posx-rRcam.x - 17 + velprojetil; rProjetil.y = posy + 14 -rRcam.y;
        velprojetil -= PROJETILVEL;
      }
      if(sentidop == 'd') {
        rProjetil.x = posx + 17 - rRcam.x + velprojetil; rProjetil.y = posy+14-rRcam.y;
        velprojetil += PROJETILVEL;
      }
      if(sentidop == 'c') {
        rProjetil.x = posx+17-rRcam.x; rProjetil.y = posy-rRcam.y + velprojetil; 
        velprojetil -= PROJETILVEL;
      }
      if(sentidop == 'b') {
        rProjetil.x = posx- rRcam.x; rProjetil.y = posy+14-rRcam.y + velprojetil;
        velprojetil += PROJETILVEL;
      }

      if(contador == 45 && !colisao) { //SOM DELE SE DESFAZENDO//
      //Mix_PlayChannel(3, projetilend, 0);
      }
      contador++;
    }
    if(contador > 45)
      stop = true;
    if(contador > 0 && contador <= DELAY_PROJETIL && !colisao && stop) {
      contador++;
      rProjetil.x = -50-rRcam.x; rProjetil.y = -50+14-rRcam.y; rProjetil.w = 28; rProjetil.h = 10;
      velprojetil = 0;
    }
    else if(contador > DELAY_PROJETIL) {
      contador = 0;
      rProjetil.x = -50-rRcam.x; rProjetil.y = -50+14-rRcam.y; rProjetil.w = 28; rProjetil.h = 10;
      velprojetil = 0;
      stop = false;
    }
  } 
  else {
    //efeito de audio//
    return;
  }
}
void player_mob(void) {
  for(int i = 0; i < numMobs && invencible == 0; i++) { 
    if(lifemob[i] > 0) { 
      colisao = collision(rR, rRm[i], 0, 0);
      if(mobwaiting == maxmobwaiting) {
        andando[idAndando] = tempAndando[idAndando];
        mobwaiting = 0;
      }
      if(colisao) {
        Mix_PlayChannel(4, damage, 0);
        if(invencible == 0) {
          kback = mob(i, colisao, rR);
          if(mobwaiting == 0) {
            tempAndando[i] = andando[i];
            andando[i] *= -1;
            idAndando = i;
          }
        }
        //printf("O Jogador Colidiu Com Um Monstro!\n");
        if(life >= 0 && invencible == 0) {
          life--;
          invencible = 1;
        }
      }
    }
  }
}
void slimeAnimated(int i) {
  static int contador = 1;
  //RECT de MOVIMENTO dos slimes//
  //passivos//
  rRm[0].x = gXm[0] + 955 - rRcam.x; rRm[0].y = gYm[0] + 24 - rRcam.y; rRm[0].w = rngx; rRm[0].h = rngy;
  rRm[1].x = gXm[1] + 745 - rRcam.x; rRm[1].y = gYm[1] + 12 - rRcam.y; rRm[1].w = rngx; rRm[1].h = rngy;
  rRm[2].x = gXm[2] + 515 - rRcam.x; rRm[2].y = gYm[2] + 129 - rRcam.y; rRm[2].w = rngx; rRm[2].h = rngy;
  rRm[3].x = gXm[3] + 330 - rRcam.x; rRm[3].y = gYm[3] + 300 - rRcam.y; rRm[3].w = rngx; rRm[3].h = rngy;
  //agressivos//
  rRm[4].x = gXm[4] + 832 - rRcam.x; rRm[4].y = gYm[4] + 250 - rRcam.y; rRm[4].w = rngx; rRm[4].h = rngy;
  rRm[5].x = gXm[5] + 318 - rRcam.x; rRm[5].y = gYm[5] + 46 - rRcam.y; rRm[5].w = rngx; rRm[5].h = rngy;
  rRm[6].x = gXm[6] + 127 - rRcam.x; rRm[6].y = gYm[6] + 342 - rRcam.y; rRm[6].w = rngx; rRm[6].h = rngy;
  rRm[7].x = gXm[7] + 20 - rRcam.x; rRm[7].y = gYm[7] + 50 - rRcam.y; rRm[7].w = rngx; rRm[7].h = rngy;
  //rect de animação dos slimes//
  if(contador > 0 && contador < 30) {
    sRm.x = 1; sRm.y = 0; sRm.w = 28; sRm.h = 19;
  }
  else if(contador > 30 && contador <= 60) {
    sRm.x = 1; sRm.y = 20; sRm.w = 28; sRm.h = 19;
  }
  else if(contador > 60 && contador <= 90) {
    sRm.x = 1; sRm.y = 40; sRm.w = 28; sRm.h = 19;
  }
  else if(contador > 90 && contador <= 120) {
    sRm.x = 1; sRm.y = 60; sRm.w = 28; sRm.h = 19;
  }
  else if(contador > 120) {
    contador = 0;
  }
  contador++;
  //printf("Oi eu sou o contador dos monstros e sou %i\n", contador);
  if(i >= 0 && i < 4)
    SDL_RenderCopy(render, monsterTex, &sRm, &rRm[i]);
  if(i >= 4 && i < 8)
    SDL_RenderCopy(render, monsterTex2, &sRm, &rRm[i]);
}
void blocksinteractive(void) {  
    bool dir = false, esq = false, cim = false, baix = false;
    bool cdir = false, cesq = false, ccim = false, cbaix = false, c = false;
  //empurrar//
    if(!interagir) {
      for(int i = 0; i < numWall && !dir; i++) {
        dir =  collision(rCaixa[0], rRw[i], vel, 0);
        cdir =  collision(rR, rCaixa[0], vel, 0);
      }
      for(int i = 0; i < numWall && !esq; i++) {
        esq =  collision(rCaixa[0], rRw[i], -vel, 0);
        cesq =  collision(rR, rCaixa[0], -vel, 0);
      }
      for(int i = 0; i < numWall && !cim; i++) {
        cim =  collision(rCaixa[0], rRw[i], 0, -vel);
        ccim =  collision(rR, rCaixa[0], 0, -vel);
      }
      for(int i = 0; i < numWall && !baix; i++) {
        baix =  collision(rCaixa[0], rRw[i], 0, vel);
        cbaix =  collision(rR, rCaixa[0], 0, vel);
      }
        if(cdir /*&& sentido == 'd'*/ && !dir && !c)
            caixax[0] += vel;
        if(cesq /*&& sentido == 'e'*/ && !esq && !c)
            caixax[0] -= vel;
        if(cbaix /*&& sentido == 'b'*/  && !baix && !c)
            caixay[0] += vel;
        if(ccim /*&& sentido == 'c'*/  && !cim && !c)
            caixay[0] -= vel;
      }
      //puxar//
      if(interagir) {
      for(int i = 0; i < numWall && !dir; i++) {
        dir =  collision(rCaixa[0], rRw[i], vel, 0);
        cdir =  collision(rR, rCaixa[0], vel, 0);
      }
      for(int i = 0; i < numWall && !esq; i++) {
        esq =  collision(rCaixa[0], rRw[i], -vel, 0);
        cesq =  collision(rR, rCaixa[0], -vel, 0);
      }
      for(int i = 0; i < numWall && !cim; i++) {
        cim =  collision(rCaixa[0], rRw[i], 0, -vel);
        ccim =  collision(rR, rCaixa[0], 0, -vel);
      }
      for(int i = 0; i < numWall && !baix; i++) {
        baix =  collision(rCaixa[0], rRw[i], 0, vel);
        cbaix =  collision(rR, rCaixa[0], 0, vel);
      }

    if(cdir /*&& sentido == 'd'*/ && !dir && !c)
        caixax[0] -= vel;
    if(cesq /*&& sentido == 'e'*/ && !esq && !c)
        caixax[0] += vel;
    if(cbaix /*&& sentido == 'b'*/  && !baix && !c)
        caixay[0] -= vel;
    if(ccim /*&& sentido == 'c'*/  && !cim && !c)
        caixay[0] += vel;
    }
  verificator();
  //renderizando//
  //caixotes topirescos lindos//
  rCaixa[0].x = caixax[0] - rRcam.x; rCaixa[0].y = caixay[0] - rRcam.y; rCaixa[0].w = 16; rCaixa[0].h = 24;
  SDL_RenderCopy(render, interactiveTex, &sCaixa[0], &rCaixa[0]);
  //portas merdas pra atrapalhar a vida//
  if(porta[0])
    rPorta[0].x = 896 - rRcam.x; rPorta[0].y = 165 - rRcam.y; rPorta[0].w = 22.5; rPorta[0].h = 18;
    SDL_RenderCopy(render, interactiveTex, &sPorta[0], &rPorta[0]);
}
void verificator(void) {
  if((rCaixa[0].x >= 770 - rRcam.x && rCaixa[0].x <= 776 + 18 - rRcam.x) 
    && (rCaixa[0].y >= 198 - rRcam.y && rCaixa[0].y <= 198 + 24 - rRcam.y) && (porta[0])) {
      porta[0] = false;
      rPorta[0].x = -50 - rRcam.x; rPorta[0].y = -50 - rRcam.y;
      printf("[Console] A porta foi aberta!\n");
      Mix_PlayChannel(1, warning, 0);
  }

}
void interaction(void) {
  colisao = false;
  colisao = collision(rR, riconCajado, 0, 0);
  if(colisao && !cajado) {
    Mix_PlayChannel(1, welcome, 0);
    cajado = true;
    riconCajado.x = -50;
    riconCajado.y = -50;
  }
}

 
                                                                                                                      // MAIN // 
int main (void) {
  //test//
  fadeSurf = SDL_CreateRGBSurface(0, 640, 400, 32, 0, 0, 0, fadeAlpha);
  //INICIANDO SDL//
  SDL_Init(SDL_INIT_EVERYTHING);
  Mix_OpenAudio(MIX_DEFAULT_FREQUENCY, MIX_DEFAULT_FORMAT, 2, 4096);
  Mix_Volume(1, 50);
  //START PLAYER//
  rR.x = gX; rR.y = gY; rR.w = 64; rR.h = 120;
  //FRAMETIME//
  const int FPS = 60;
  const int frameDelay = 1000/ FPS;
  int frameStart;
  int frameTime;
  //Start em Window//
  if(!janela()) {
    printf("A TELA NÃO INICIOU!");
  }
  else{
    //GAME HERE//
    printf("[Console]tela iniciada\n");
    surfaces();
    printf("[Console]surfaces carregadas\n");
    audio();
    printf("[Console]audio iniciado\n");
    printf("[Console]o Jogo ira iniciar...\n");
    printf(". ");
    printf(". ");
    printf(".\n");
    printf("[Console]iniciando!\n");
    Mix_PlayChannel(1, welcome, 0);
    //Mix_PlayMusic(fightmusic, -1);
    //TIRANDO O ALPHA DO WALL/
    //SDL_SetTextureAlphaMod(wallTex, 0);
    //definindo o inicio da tela//
    salaAtual();
    salaCamera();
    //reescalando//
    rescalar();
    SDL_RenderSetLogicalSize(render, 640, 400);

    renderizar();
    teladeAnimacaoIN();
    while(gaming) {                                                                                                             //GAME LOOP//
      //FRAMES//
        frameStart = SDL_GetTicks();
      //Eventos//
      while(SDL_PollEvent(&event)){
        //X to close//
        if (event.type == SDL_QUIT)
          gaming = false;
        //reconhecendo movimentos//
        movements();
      }
      // RESCALAR JANELA E SPRITES //
      rescalar();
      SDL_RenderSetLogicalSize(render, 640, 400);

      // dando movimentos & ações//
      makemovements();
      projetilF();
      if(interagir) {
        //printf("[Console]Vamos tentar achar um objeto para voce!\n");
        interaction();
      }
      //camera//
        //camera e sala//
      salaAtual();
      salaCamera();
      // movimentos dos mobs //
      for(int i = 0; i < numMobs; i++)
        lixo = mob(i, colisao, rR);
      // COLISORES //
      // PLAYER -> MOB//
      player_mob();
      invencibleF();
      //KNOCKBACK//
      knockb();
      // APRESENTANDO AO USUARIO //
      renderizar();
      SDL_RenderPresent(render);
      //morte//
      if(life < 0 && invencible == 0) {
            gaming = false;
            Mix_PlayChannel(1, death, 0);
            SDL_Delay(1000);
            printf("\n\n\n[Console]Voce Perdeu, Meu Consagrado! \n\n\n");
          }
      //FRAME DELAY//
      frameTime = SDL_GetTicks() - frameStart;
      if(frameDelay > frameTime) {
        SDL_Delay(frameDelay - frameTime);
      }
    }
    teladeAnimacaoOUT();

  }
  //Destroy//
  SDL_DestroyWindow(gJanela);
  SDL_DestroyTexture(playerTex);
  SDL_DestroyTexture(monsterTex);
  SDL_DestroyTexture(wallTex);
  SDL_DestroyTexture(mapTex);
  SDL_DestroyTexture(heartTex);
  //FIM//
  Mix_Quit();
  SDL_Quit();   
}