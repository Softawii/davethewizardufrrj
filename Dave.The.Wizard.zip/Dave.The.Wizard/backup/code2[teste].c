#include <stdio.h> // FUNCOES BASICAS // se necessario
#include <stdbool.h> // BOOLEANAS //
#include <SDL2/SDL.h> //SDL LIBRARY //
#include <SDL2/SDL_image.h>
#include "player.h"
//VARIAVEIS, SURFACES, ETC//

int w=1920,h=1080;
bool gaming = true; //GAME LOOP//
int gX = 300, gY = 300; //MOVIMENTAÇÃO//
int x, y; //VARIAVEIS EXTRAS//
int gXm = 0, gYm = 0;// MOV MONSTER//
SDL_Window* gJanela = NULL; // CRIANDO JANELA //

SDL_Renderer* render;// Render da Screen //

SDL_Texture* playerTex; //textura do Personagem
SDL_Surface* playerSurf; //Surface do Player

SDL_Texture* monsterTex; //textura do monstro//
SDL_Surface* monsterSurf; //surface do player//

SDL_Event event; //LER EVENTOS//

SDL_Rect rR = {gX, gY, 64,120};


//CHAMADA//
bool janela (void);
bool surfaces (void);
bool renderizar(void);
bool rescalar(void);
void movements (void);
void makemovements(void);
void mob (void);
// FUNCOES //
bool renderizar(SDL_Rect rR) {
  //RECT do Player//
  SDL_Rect sR = {0,0,32,60};
  //RECT do MONSTRO//
  SDL_Rect sRm = {0,0,32,32};
  SDL_Rect rRm = {gXm + 700,gYm + 700,120,120};
  SDL_Rect rRm1 = {500 + gXm, 100 + gYm,120,120};
  SDL_Rect rRm2 = {400 + gXm, 200 + gYm,120,120};

  //Renderizar//
  SDL_RenderClear(render);
  //MOVIMENT DO PLAYER//
  SDL_RenderCopy(render, playerTex, &sR, &rR);
  //MOVIMENT DOS MONSTROS//
  SDL_RenderCopy(render, monsterTex, &sRm, &rRm );
  SDL_RenderCopy(render, monsterTex, &sRm, &rRm1 );
  SDL_RenderCopy(render, monsterTex, &sRm, &rRm2 );

  SDL_RenderPresent(render);
}
bool surfaces (void) {
  //Gerando Texturas e Sprites do Player//
  //PLAYER SPRITES//
  playerSurf = IMG_Load("sprites/princess.png");
  playerTex = SDL_CreateTextureFromSurface(render, playerSurf);
  SDL_FreeSurface(playerSurf);
  //MONSTER1//
  monsterSurf = IMG_Load("sprites/monster.png");
  monsterTex = SDL_CreateTextureFromSurface(render, monsterSurf);
  SDL_FreeSurface(monsterSurf);
}
bool janela (void) {
  bool success = true;
  // START //
  if(SDL_Init(SDL_INIT_VIDEO) < 0) {
    printf("Ocorreu um imprevisto! :(, %s\n", SDL_GetError());
      success = false;
      // A TELA NÃO INICIOU //
  }
  else {
    //VARIAVEIS//
    gJanela = SDL_CreateWindow("NOME DO JOGO", SDL_WINDOWPOS_CENTERED,SDL_WINDOWPOS_CENTERED, w,h, SDL_WINDOW_RESIZABLE);
      if(gJanela == NULL) {
          printf("Ocorreu um imprevisto! :(, %s\n", SDL_GetError()); 
            success = false;
        }
      else{
          render = SDL_CreateRenderer(gJanela, -1, 0);
          SDL_SetRenderDrawColor(render, 217, 172, 37, 255);
        }
  }
  //FIM//
  return success;
}
bool rescalar(void){
   if(event.type ==SDL_WINDOWEVENT)
      if(event.type ==SDL_WINDOWEVENT_RESIZED)
      {
        w=event.window.data1;
        h=event.window.data2;
    }
}

void mob (void) {
  static int dir = -1, esq = 1;
  if(gXm >= 80) {
    dir = -1;
    esq = 1;
  }
  if(gXm <= -80) {
    dir = 1;
    esq = -1;
  }
  if(dir == 1 && esq == -1)
    gXm += 2;
  if(esq == 1 && dir == -1)
    gXm -= 2;
}

int main (void) {
  //INICIANDO SDL//
  SDL_Init(SDL_INIT_EVERYTHING);
  //Start em Window//
  if(!janela()) {
    printf("A TELA NÃO INICIOU!");
  }
  else{
    //GAME HERE//
    surfaces();
    while(gaming) {
      //Eventos//
      while(SDL_PollEvent(&event)){
        //X to close//
        if (event.type == SDL_QUIT)
          gaming = false;
        //reconhecendo movimentos//
        movements();
      }
      //RESCALAR JANELA E SPRITES
      rescalar();
      SDL_RenderSetLogicalSize(render, 1920, 1080);
      //dando movimentos//
      rR = makemovements();
      //movimentos dos mobs//
      mob();
      //APRESENTANDO AO USUARIO//
      renderizar(rR);
      SDL_Delay(1000/60);
    }
  }
  //Destroy//
  SDL_DestroyWindow(gJanela);
  SDL_DestroyTexture(playerTex);
  SDL_DestroyTexture(monsterTex);
  //FIM//
  SDL_Quit();   
}