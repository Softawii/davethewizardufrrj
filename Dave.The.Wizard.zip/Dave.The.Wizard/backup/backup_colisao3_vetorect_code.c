#include <stdio.h> // FUNCOES BASICAS // se necessario
#include <stdbool.h> // BOOLEANAS //
#include <SDL2/SDL.h> //SDL LIBRARY //
#include <SDL2/SDL_image.h>
//VARIAVEIS, SURFACES, ETC//
int w=1920,h=1080;
bool gaming = true; //GAME LOOP//
int gX = 300, gY = 300; //MOVIMENTAÇÃO//
int x, y; //VARIAVEIS EXTRAS//
int gXm = 0, gYm = 0;// MOV MONSTER//
//COLISOES//
bool colisao = false;
int e = 0, d = 0,c = 0, b = 0;



SDL_Window* gJanela = NULL; // CRIANDO JANELA //

SDL_Renderer* render;// Render da Screen //

SDL_Texture* playerTex; //textura do Personagem
SDL_Surface* playerSurf; //Surface do Player

SDL_Texture* monsterTex; //textura do monstro//
SDL_Surface* monsterSurf; //surface do player//

SDL_Texture* wallTex; //textura do monstro//
SDL_Surface* wallSurf; //surface do player//

SDL_Event event; //LER EVENTOS//


//CHAMADA//
bool janela (void);
bool surfaces (void);
bool renderizar(void);
bool rescalar(void);
void movements (void);
void makemovements(void);
void mob (void);
// FUNCOES //
                                                                                  //INICIAÇÃO//
bool surfaces (void) {
                                                                      //Gerando Texturas e Sprites do Player//
  //PLAYER SPRITES//
  playerSurf = IMG_Load("sprites/princess.png");
  playerTex = SDL_CreateTextureFromSurface(render, playerSurf);
  SDL_FreeSurface(playerSurf);
  //MONSTER1//
  monsterSurf = IMG_Load("sprites/monster.png");
  monsterTex = SDL_CreateTextureFromSurface(render, monsterSurf);
  SDL_FreeSurface(monsterSurf);
  //WALL//
  wallSurf = IMG_Load("sprites/wall.png");
  wallTex = SDL_CreateTextureFromSurface(render, wallSurf);
  SDL_FreeSurface(wallSurf);
}
bool janela (void) {
  bool success = true;
  // START //
  if(SDL_Init(SDL_INIT_VIDEO) < 0) {
    printf("Ocorreu um imprevisto! :(, %s\n", SDL_GetError());
      success = false;
      // A TELA NÃO INICIOU //
  }
  else {
    //VARIAVEIS//
    gJanela = SDL_CreateWindow("NOME DO JOGO", SDL_WINDOWPOS_CENTERED,SDL_WINDOWPOS_CENTERED, w,h, SDL_WINDOW_RESIZABLE);
      if(gJanela == NULL) {
          printf("Ocorreu um imprevisto! :(, %s\n", SDL_GetError()); 
            success = false;
        }
      else{
          render = SDL_CreateRenderer(gJanela, -1, 0);
          SDL_SetRenderDrawColor(render, 217, 172, 37, 255);
        }
  }
  //FIM//
  return success;
}
bool rescalar(void){
   if(event.type ==SDL_WINDOWEVENT)
      if(event.type ==SDL_WINDOWEVENT_RESIZED)
      {
        w=event.window.data1;
        h=event.window.data2;
    }
}
                                                                                              //MOVIMENTOS E RENDER//
void movements (void) {
  // RECONHECER MOVIMENTOS //
  if(event.type == SDL_KEYDOWN) { // Pressionando as teclas //
    if(event.key.keysym.sym == SDLK_LEFT)
        x = 1;
    if(event.key.keysym.sym == SDLK_RIGHT)
        x = -1;
      if(event.key.keysym.sym == SDLK_UP)
        y = 1;
    if(event.key.keysym.sym == SDLK_DOWN)
        y = -1;
  }
  else if(event.type == SDL_KEYUP) { // Despressionando as teclas //
    if(event.key.keysym.sym == SDLK_LEFT)
        x = 0;
    if(event.key.keysym.sym == SDLK_RIGHT)
        x = 0;
    if(event.key.keysym.sym == SDLK_UP)
        y = 0;
    if(event.key.keysym.sym == SDLK_DOWN)
        y = 0; 
  }
}
void makemovements(void) {
  // DANDO MOVIMENTOS //
  if(!colisao) {  
    if(x == -1 && d == 0) // Direita //
      gX += 8;
    if(x == 1 && e == 0) // ESQUERDA //
      gX -= 8;
    if(y == -1 && b == 0) //  BAIXO //
      gY += 8;
    if(y == 1 && c == 0) // CIMA //
      gY -= 8; 
  }
}
bool collision(int aX, int aY,int aLarg, int aAlt, int bX, int bY, int bLarg, int bAlt) {
  if (aY + aAlt < bY) return false;
  else if(aY > bY + bAlt) return false;
  else if(aX + aLarg < bX) return false;
  else if(aX > bX + bLarg) return false;
  
  return true;
}
void collision2(int aX, int aY,int aLarg, int aAlt, int bX, int bY, int bLarg, int bAlt) {
  //c = 0; b = 0; d = 0; e = 0;
  if (aY + aAlt > bY && aY + aAlt < bY + bAlt) // baixo //
     gY -= 8;
  if(aY < bY + bAlt && aY > bY) // cima //
    gY += 8;
  if(aX + aLarg > bX && aX + aLarg < bX + bLarg) // direita //
    gX -= 8;
  if(aX < bX + bLarg && aX > bX) // esquerda //
    gX += 8;
}

void mob (void) {
  static int dir = -1, esq = 1;
  if(gXm >= 80) {
    dir = -1;
    esq = 1;
  }
  if(gXm <= -80) {
    dir = 1;
    esq = -1;
  }
  if(dir == 1 && esq == -1)
    gXm += 2;
  if(esq == 1 && dir == -1)
    gXm -= 2;
}


bool renderizar(void) {
  //RECT do Player//
  SDL_Rect sR = {0,0,32,60};
  SDL_Rect rR = {gX, gY, 64,120};
  //RECT do MONSTRO//
  SDL_Rect sRm = {0,0,32,32};
  SDL_Rect rRm[2];
  rRm[0].x = gXm + 700; rRm[0].y = gYm + 700; rRm[0].w = 120; rRm[0].h = 120;
  rRm[1].x = gXm + 10; rRm[1].y = gYm + 70; rRm[1].w = 240; rRm[1].h = 240;
  //RECT do Wall//
  SDL_Rect sRw = {0,0,32,32};
  SDL_Rect rRw = {1280, 720, 128,64};

  //Renderizar//
  SDL_RenderClear(render);
  //MOVIMENT DO PLAYER//
  SDL_RenderCopy(render, playerTex, &sR, &rR);
  //MOVIMENT DOS MONSTROS//
  SDL_RenderCopy(render, monsterTex, &sRm, &rRm[0]);
  SDL_RenderCopy(render, monsterTex, &sRm, &rRm[1]);
  //RENDER DO WALL//
  SDL_RenderCopy(render, wallTex, &sRw, &rRw);
  //PRESENT//
  SDL_RenderPresent(render);
}
                                                                                                                      // MAIN // 
int main (void) {
  //INICIANDO SDL//
  SDL_Init(SDL_INIT_EVERYTHING);
  //Start em Window//
  if(!janela()) {
    printf("A TELA NÃO INICIOU!");
  }
  else{
    //GAME HERE//
    surfaces();
    while(gaming) {                                                                                                             //GAME LOOP//
      //Eventos//
      while(SDL_PollEvent(&event)){
        //X to close//
        if (event.type == SDL_QUIT)
          gaming = false;
        //reconhecendo movimentos//
        movements();
      }
      // RESCALAR JANELA E SPRITES //
      rescalar();
      SDL_RenderSetLogicalSize(render, 1920, 1080);
      // dando movimentos //
      makemovements();
      // movimentos dos mobs //
      mob();
      // COLISORES //
      colisao = collision(gX,gY,64,120,1280,720,128,64);
     if(colisao)
        collision2(gX,gY,64,120,1280,720,128,64);
      // APRESENTANDO AO USUARIO //
      renderizar();
      SDL_Delay(1000/60);
    }
  }
  //Destroy//
  SDL_DestroyWindow(gJanela);
  SDL_DestroyTexture(playerTex);
  SDL_DestroyTexture(monsterTex);
  SDL_DestroyTexture(wallTex);
  //FIM//
  SDL_Quit();   
}