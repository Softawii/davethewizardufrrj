#include <stdio.h> // FUNCOES BASICAS // se necessario
#include <stdbool.h> // BOOLEANAS //
#include <SDL2/SDL.h> //SDL LIBRARY //
#include <SDL2/SDL_image.h>
//VARIAVEIS, SURFACES, ETC//
int w=1920,h=1080;
bool gaming = true; //GAME LOOP//
int gX = 300, gY = 300; //MOVIMENTAÇÃO//
int x, y; //VARIAVEIS EXTRAS//

int gXm[4] = {0, 20, 30, 40};// MOV MONSTER// 
int gYm[4] = {0, 20, 30, 40};// MOV MONSTER//
int gXmi[4] = {0, 20, 30, 40};// MOV INICIAL MONSTER// 
int gXmv[4] = {4, 2, 4, 8};// VEL INICIAL MONSTER// 
int gXmr[4] = {800, 20, 200, 400};// RANGE MONSTER// 
//COLISOES//
bool colisao = false;

//WALL//
SDL_Rect rRw[4];
SDL_Texture* wallTex; //textura do monstro//
SDL_Surface* wallSurf; //surface do player//

//MONSTER//
SDL_Rect rRm[4];
SDL_Texture* monsterTex; //textura do monstro//
SDL_Surface* monsterSurf; //surface do player//

//PLAYER//
SDL_Rect rR;
SDL_Texture* playerTex; //textura do Personagem
SDL_Surface* playerSurf; //Surface do Player

//null//

SDL_Window* gJanela = NULL; // CRIANDO JANELA //

SDL_Renderer* render;// Render da Screen //

SDL_Event event; //LER EVENTOS//


//CHAMADA//
bool janela (void);
bool surfaces (void);
bool renderizar(void);
bool rescalar(void);
void movements (void);
void makemovements(void);
void mob (int i, bool colisao);
// FUNCOES //
                                                                                  //INICIAÇÃO//
bool surfaces (void) {
                                                                      //Gerando Texturas e Sprites do Player//
  //PLAYER SPRITES//
  playerSurf = IMG_Load("sprites/princess.png");
  playerTex = SDL_CreateTextureFromSurface(render, playerSurf);
  SDL_FreeSurface(playerSurf);
  //MONSTER1//
  monsterSurf = IMG_Load("sprites/monster.png");
  monsterTex = SDL_CreateTextureFromSurface(render, monsterSurf);
  SDL_FreeSurface(monsterSurf);
  //WALL//
  wallSurf = IMG_Load("sprites/wall.png");
  wallTex = SDL_CreateTextureFromSurface(render, wallSurf);
  SDL_FreeSurface(wallSurf);
}
bool janela (void) {
  bool success = true;
  // START //
  if(SDL_Init(SDL_INIT_VIDEO) < 0) {
    printf("Ocorreu um imprevisto! :(, %s\n", SDL_GetError());
      success = false;
      // A TELA NÃO INICIOU //
  }
  else {
    //VARIAVEIS//
    gJanela = SDL_CreateWindow("NOME DO JOGO", SDL_WINDOWPOS_CENTERED,SDL_WINDOWPOS_CENTERED, w,h, SDL_WINDOW_RESIZABLE);
      if(gJanela == NULL) {
          printf("Ocorreu um imprevisto! :(, %s\n", SDL_GetError()); 
            success = false;
        }
      else{
          render = SDL_CreateRenderer(gJanela, -1, 0);
          SDL_SetRenderDrawColor(render, 217, 172, 37, 255);
        }
  }
  //FIM//
  return success;
}
bool rescalar(void){
   if(event.type ==SDL_WINDOWEVENT)
      if(event.type ==SDL_WINDOWEVENT_RESIZED)
      {
        w=event.window.data1;
        h=event.window.data2;
    }
}
                                                                                              //MOVIMENTOS E RENDER//
void movements (void) {
  // RECONHECER MOVIMENTOS //
  if(event.type == SDL_KEYDOWN) { // Pressionando as teclas //
    if(event.key.keysym.sym == SDLK_LEFT)
        x = 1;
    if(event.key.keysym.sym == SDLK_RIGHT)
        x = -1;
      if(event.key.keysym.sym == SDLK_UP)
        y = 1;
    if(event.key.keysym.sym == SDLK_DOWN)
        y = -1;
  }
  else if(event.type == SDL_KEYUP) { // Despressionando as teclas //
    if(event.key.keysym.sym == SDLK_LEFT)
        x = 0;
    if(event.key.keysym.sym == SDLK_RIGHT)
        x = 0;
    if(event.key.keysym.sym == SDLK_UP)
        y = 0;
    if(event.key.keysym.sym == SDLK_DOWN)
        y = 0; 
  }
}
void makemovements(void) {
  // DANDO MOVIMENTOS //
  if(!colisao) {  
    if(x == -1) // Direita //
      gX += 8;
    if(x == 1 ) // ESQUERDA //
      gX -= 8;
    if(y == -1) //  BAIXO //
      gY += 8;
    if(y == 1) // CIMA //
      gY -= 8; 
  }
}
bool collision(int aX, int aY,int aLarg, int aAlt, int bX, int bY, int bLarg, int bAlt) {
  if (aY + aAlt < bY) return false;
  else if(aY > bY + bAlt) return false;
  else if(aX + aLarg < bX) return false;
  else if(aX > bX + bLarg) return false;
  
  return true;
}
void collision2(int aX, int aY,int aLarg, int aAlt, int bX, int bY, int bLarg, int bAlt) {
  //c = 0; b = 0; d = 0; e = 0;
  if (aY + aAlt > bY && aY + aAlt < bY + bAlt) // baixo //
     gY -= 8;
  if(aY < bY + bAlt && aY > bY) // cima //
    gY += 8;
  if(aX + aLarg > bX && aX + aLarg < bX + bLarg) // direita //
    gX -= 8;
  if(aX < bX + bLarg && aX > bX) // esquerda //
    gX += 8;
}

void mob (int i, bool colisao) {
  static int dir[4] = {1,-1,1,-1}; 
  static int esq[4] = {-1,1,-1,1};
  if(gXm[i] >= gXmi[i] + gXmr[i]) {
    dir[i] = -1;
    esq[i] = 1;
  }
  if(gXm[i] <= gXmi[i] - gXmr[i]) {
    dir[i] = 1;
    esq[i] = -1;
  }
  if(dir[i] == 1 && esq[i] == -1)
    gXm[i] += gXmv[i];
  if(esq[i] == 1 && dir[i] == -1)
    gXm[i] -= gXmv[i];
}


bool renderizar(void) {
  //RECT do Player//
  SDL_Rect sR = {0,0,32,60};
  rR.x = gX; rR.y = gY; rR.w = 64; rR.h = 64;
  //RECT do MONSTRO//
  SDL_Rect sRm = {0,0,32,32};
  rRm[0].x = gXm[0] + 700; rRm[0].y = gYm[0] + 700; rRm[0].w = 120; rRm[0].h = 120;
  rRm[1].x = gXm[1] + 500; rRm[1].y = gYm[1] + 700; rRm[1].w = 120; rRm[1].h = 120;
  rRm[2].x = gXm[2] + 800; rRm[2].y = gYm[2] + 200; rRm[2].w = 120; rRm[2].h = 120;
  rRm[3].x = gXm[3] + 300; rRm[3].y = gYm[3] + 900; rRm[3].w = 120; rRm[3].h = 120;
  //RECT do Wall//
  SDL_Rect sRw = {0,0,32,32};
  rRw[0].x = 0; rRw[0].y = 0; rRw[0].w = 32; rRw[0].h = 1920; //WALL CANTO ESQUERDO //
  rRw[1].x = 1920-32; rRw[1].y = 0; rRw[1].w = 32; rRw[1].h = 1920; // WALL CANTO DIREITO //
  rRw[2].x = 0; rRw[2].y = 0; rRw[2].w = 1920; rRw[2].h = 32; // WALL CIMA //
  rRw[3].x = 0; rRw[3].y = 64+32; rRw[3].w = 1800; rRw[3].h = 32; // WALL BAIXO // 

  //Renderizar//
  SDL_RenderClear(render);
  //MOVIMENT DO PLAYER//
  SDL_RenderCopy(render, playerTex, &sR, &rR);
  //MOVIMENT DOS MONSTROS//
  for(int i = 0; i < 4; i++)
    SDL_RenderCopy(render, monsterTex, &sRm, &rRm[i]);
  //RENDER DO WALL//
  for(int i = 0; i < 4; i++)
    SDL_RenderCopy(render, wallTex, &sRw, &rRw[i]);
  //PRESENT//
  SDL_RenderPresent(render);
}
                                                                                                                      // MAIN // 
int main (void) {
  //INICIANDO SDL//
  SDL_Init(SDL_INIT_EVERYTHING);
  //START PLAYER//
  rR.x = gX; rR.y = gY; rR.w = 64; rR.h = 120;
  //Start em Window//
  if(!janela()) {
    printf("A TELA NÃO INICIOU!");
  }
  else{
    //GAME HERE//
    surfaces();
    printf("o jogo esta iniciando\n");
    while(gaming) {                                                                                                             //GAME LOOP//
      //Eventos//
      while(SDL_PollEvent(&event)){
        //X to close//
        if (event.type == SDL_QUIT)
          gaming = false;
        //reconhecendo movimentos//
        movements();
      }
      // RESCALAR JANELA E SPRITES //
      rescalar();
      SDL_RenderSetLogicalSize(render, 1920, 1080);
      
      // dando movimentos //
      makemovements();
      // movimentos dos mobs //
      for(int i = 0; i < 4; i++)
        mob(i, colisao);
      
      // COLISORES //
      //PLAYER -> WALL//
      for(int i = 0; i < 4; i++) { 
        colisao = collision(rR.x, rR.y, rR.w, rR.h, rRw[i].x, rRw[i].y, rRw[i].w, rRw[i].h);
        if(colisao)
          collision2(rR.x, rR.y, rR.w, rR.h, rRw[i].x, rRw[i].y, rRw[i].w, rRw[i].h);
      }
      // PLAYER -> MOB//
      for(int i = 0; i < 4; i++) { 
        colisao = collision(rR.x, rR.y, rR.w, rR.h, rRm[i].x, rRm[i].y, rRm[i].w, rRm[i].h);
        if(colisao) {
          printf("o jogador colidiu com um monstro\n");
          gaming = false;
          printf("\n\n\n\n\n VOCE PERDEU! \n\n\n\n\n");
        }
      }
      // APRESENTANDO AO USUARIO //
      renderizar();
      SDL_Delay(1000/60);
    }

  }
  //Destroy//
  SDL_DestroyWindow(gJanela);
  SDL_DestroyTexture(playerTex);
  SDL_DestroyTexture(monsterTex);
  SDL_DestroyTexture(wallTex);
  //FIM//
  SDL_Quit();   
}