#include <stdio.h> // FUNCOES BASICAS // se necessario
#include <stdbool.h> // BOOLEANAS //
#include <SDL2/SDL.h> //SDL LIBRARY //
#include <SDL2/SDL_image.h>
#include <SDL2/SDL_mixer.h>
//VARIAVEIS, SURFACES, ETC//
int w=640,h=400;
bool gaming = true; //GAME LOOP//
int gX = 300, gY = 300; //MOVIMENTAÇÃO//
int x, y; //VARIAVEIS EXTRAS//


int lixo = 0; //trash//
int gXm[4] = {0, 20, 30, 40};// MOV MONSTER// 
int gYm[4] = {0, 20, 30, 40};// MOV MONSTER//
int gXmi[4] = {0, 20, 30, 40};// MOV INICIAL MONSTER// 
int gXmv[4] = {4, 2, 4, 8};// VEL INICIAL MONSTER// 
int gXmr[4] = {800, 20, 200, 400};// RANGE MONSTER// 
//COLISOES//
bool colisao = false;
//MAP//
SDL_Rect rRcam = {0,0,640, 400};
SDL_Texture* mapTex; //textura da wall//
SDL_Surface* mapSurf; //surface da wall//
int mapw = 2560;
int maph = 1200;


//WALL//
SDL_Rect rRw[4];
SDL_Texture* wallTex; //textura da wall//
SDL_Surface* wallSurf; //surface da wall//
int numWall = 4;

//MONSTER//
SDL_Rect rRm[4];
SDL_Texture* monsterTex; //textura do monstro//
SDL_Surface* monsterSurf; //surface do player//
int rng = 64;
int andando[4] = {1,-1,1,-1};
int tempAndando[4] = {0}, idAndando;
int mobwaiting = 0;
int maxmobwaiting = 120;
int numMobs = 4;


//PLAYER//
SDL_Rect rR;
SDL_Rect sR;
SDL_Texture* playerTex; //textura do Personagem
SDL_Surface* playerSurf; //Surface do Player
int life = 5; //VIDA DO PLAYER//
int invencible = 0; //INVENCIBILIDADE DE DANO//
int kback = 0; //knockback//
int kbacktime = 0; //knockback time//
int vel = 4; // VELOCIDADE DO PLAYER //
char sentido = 'b';

//hud//
SDL_Rect rH; //rect HUD//
SDL_Texture* heartTex; //textura do Personagem
SDL_Surface* heartSurf; //Surface do Player

SDL_Window* gJanela = NULL; // CRIANDO JANELA //

SDL_Renderer* render;// Render da Screen //

SDL_Event event; //LER EVENTOS//

//AUDIO//
Mix_Chunk* damage;
Mix_Chunk* death;
Mix_Chunk* hitwall;
Mix_Chunk* welcome;
Mix_Music* fight;

//CHAMADA//
bool janela (void);
void surfaces (void);
bool renderizar(void);
bool rescalar(void);
void movements (void);
void makemovements(void);
int mob (int i, bool colisao);
void teladeAnimacao (void);
// FUNCOES //
                                                                               //INICIAÇÃO//
void audio(void) {
  damage = Mix_LoadWAV("sfx/damage.wav");
  death = Mix_LoadWAV("sfx/death.wav");
  hitwall = Mix_LoadWAV("sfx/hitwall.wav");
  welcome = Mix_LoadWAV("sfx/welcome.wav");
  fight = Mix_LoadMUS("songs/fight.mp3");
}
void surfaces (void) {
                                                                   //Gerando Texturas e Sprites do Player//
  //PLAYER SPRITES//
  playerSurf = IMG_Load("sprites/char.png");
  playerTex = SDL_CreateTextureFromSurface(render, playerSurf);
  SDL_FreeSurface(playerSurf);
  //MONSTER1//
  monsterSurf = IMG_Load("sprites/monster.png");
  monsterTex = SDL_CreateTextureFromSurface(render, monsterSurf);
  SDL_FreeSurface(monsterSurf);
  //WALL//
  wallSurf = IMG_Load("sprites/wall.png");
  wallTex = SDL_CreateTextureFromSurface(render, wallSurf);
  SDL_FreeSurface(wallSurf);
  //MAP//
  mapSurf = IMG_Load("img/world.png");
  mapTex = SDL_CreateTextureFromSurface(render, mapSurf);
  SDL_QueryTexture(mapTex, NULL, NULL, &mapw, &maph);
  SDL_FreeSurface(mapSurf);
  //HEART//
  heartSurf = IMG_Load("sprites/hud_heart.png");
  heartTex = SDL_CreateTextureFromSurface(render, heartSurf);
  SDL_FreeSurface(heartSurf);
}
bool janela (void) {
  bool success = true;
  // START //
  if(SDL_Init(SDL_INIT_VIDEO) < 0) {
    printf("Ocorreu um imprevisto! :(, %s\n", SDL_GetError());
      success = false;
      // A TELA NÃO INICIOU //
  }
  else {
    printf("[Console]SDL iniciado!\n");
    SDL_Delay(100);
    //VARIAVEIS//
    gJanela = SDL_CreateWindow("NOME DO JOGO", SDL_WINDOWPOS_CENTERED,SDL_WINDOWPOS_CENTERED, w,h, SDL_WINDOW_RESIZABLE);
      if(gJanela == NULL) {
          printf("Ocorreu um imprevisto! :(, %s\n", SDL_GetError()); 
            success = false;
        }
      else{
          render = SDL_CreateRenderer(gJanela, -1, 0);
          SDL_SetRenderDrawColor(render, 0, 0, 0, 255);
        }
  }
  //FIM//
  return success;
}
bool rescalar(void){
   if(event.type ==SDL_WINDOWEVENT)
      if(event.type ==SDL_WINDOWEVENT_RESIZED)
      {
        w=event.window.data1;
        h=event.window.data2;
    }
}
                                                                                              //MOVIMENTOS E RENDER//
void movements (void) {
  // RECONHECER MOVIMENTOS //
  if(event.type == SDL_KEYDOWN && kbacktime == 0) { // Pressionando as teclas //
    if(event.key.keysym.sym == SDLK_LEFT) {
        x = -1;
        sentido = 'e';
    }
    if(event.key.keysym.sym == SDLK_RIGHT) {
        x = 1;
        sentido = 'd';
    }
    if(event.key.keysym.sym == SDLK_UP) {
        y = -1;
        sentido = 'c';
    }
    if(event.key.keysym.sym == SDLK_DOWN) {
        y = 1;
        sentido = 'b';
    }
  }
  if(event.type == SDL_KEYUP) { // Despressionando as teclas //
    if(event.key.keysym.sym == SDLK_LEFT)
        x = 0;
    if(event.key.keysym.sym == SDLK_RIGHT)
        x = 0;
    if(event.key.keysym.sym == SDLK_UP)
        y = 0;
    if(event.key.keysym.sym == SDLK_DOWN)
        y = 0; 
  }
}
void makemovements(void) {
  // DANDO MOVIMENTOS //
  if(!colisao && kbacktime == 0) {  
    if(x == 1) // Direita //
      gX += vel;
    if(x == -1 ) // ESQUERDA //
      gX -= vel;
    if(y == 1) //  BAIXO //
      gY += vel;
    if(y == -1) // CIMA //
      gY -= vel; 
  }
}
bool collision(int aX, int aY,int aLarg, int aAlt, int bX, int bY, int bLarg, int bAlt) {
  if (aY + aAlt < bY) return false;
  else if(aY > bY + bAlt) return false;
  else if(aX + aLarg < bX) return false;
  else if(aX > bX + bLarg) return false;
  
  return true;
}
void collision2(int aX, int aY,int aLarg, int aAlt, int bX, int bY, int bLarg, int bAlt, int velocidade) {
  if (aY /*- vel*/ + aAlt > bY && aY + aAlt < bY + bAlt) // baixo //
     gY -= velocidade;
  if(aY /*+ vel*/ < bY + bAlt && aY > bY) // cima //
    gY += velocidade;
  if(aX /*- vel/4*/ + aLarg > bX && aX + aLarg < bX + bLarg) // direita //
    gX -= velocidade;
  if(aX /*+ vel*/ < bX + bLarg && aX > bX) // esquerda //
    gX += velocidade;
}
int collisionMob(int aX, int aY,int aLarg, int aAlt, int bX, int bY, int bLarg, int bAlt, int mobdirec) {
  if(mobdirec == 1) /*DIREITA*/ {
    return 1;
  }
  else if(mobdirec == -1) /*ESQUERDA*/ {
    return -1;
  }

}

int mob (int i, bool colid) { 
  if(gXm[i] >= gXmi[i] + gXmr[i]) {
    andando[i] = -1;
  }
  if(gXm[i] <= gXmi[i] - gXmr[i]) {
    andando[i] = 1;
  }
  if(andando[i] == 1)
    gXm[i] += gXmv[i];
  if(andando[i] == -1)
    gXm[i] -= gXmv[i];

  return andando[i];
}
void playerAnimated(void /*config*/) {
  //RECT do Player//
  static int move = 0;
  static int contador = 1;
  //SEM DANO//
  //FRENTE//
  if(y == -1) {
    if(contador >= 0 && contador <= 8)
      move = 0;
    if(contador > 8 && contador <= 16)
      move = 1;
    if(contador > 16 && contador <= 24)
      move = 2;
    if(contador > 24 && contador <= 32)
      move = 3;
    if(contador > 32) {
      move = 0;
      contador = 0;
    }
    sR.x = 4 + 24*move; sR.y = 70; sR.w = 16; sR.h = 25;
    if(invencible > 0) {
      sR.x = 100 + 24*move;
    }
  }
  //COSTAS//
  else if(y == 1 && kbacktime == 0) {
    if(contador >= 0 && contador <= 8)
      move = 0;
    if(contador > 8 && contador <= 16)
      move = 1;
    if(contador > 16 && contador <= 24)
      move = 2;
    if(contador > 24 && contador <= 32)
      move = 3;
    if(contador > 32) {
      move = 0;
      contador = 0;
    }
    sR.x = 4 + 24*move; sR.y = 6; sR.w = 16; sR.h = 25;
    if(invencible > 0) {
      sR.x = 100 + 24*move;
    }
  }
  //LADO DIREITO//
  else if(x == 1 && kbacktime == 0) {
    if(contador >= 0 && contador <= 8)
      move = 0;
    if(contador > 8 && contador <= 24)
      move = 1;
    if(contador > 24) {
      move = 0;
      contador = 0;
    }
    if(contador > 32) {
      move = 0;
      contador = 0;
    }
    sR.x = 53 + 23*move; sR.y = 38; sR.w = 16; sR.h = 25;
    if(invencible > 0) {
      sR.x = 149 + 24*move;
    }
  }
  //LADO ESQUERDO//
  else if(x == -1 && kbacktime == 0) {
    if(contador >= 0 && contador <= 16)
      move = 0;
    if(contador > 16 && contador <= 32)
      move = 1;
    if(contador > 32) {
      move = 0;
      contador = 0;
    }
    sR.x = 5 + 24*move; sR.y = 38; sR.w = 16; sR.h = 25;
    if(invencible > 0) {
      sR.x = 101 + 24*move;
    }
  }
  else {
    if(contador >= 0 && contador <= 32)
      move = 0;
    if(contador > 32) {
      move = 0;
      contador = 0;
    }
    if(sentido == 'b') {
      sR.x = 4; sR.y = 6; sR.w = 16; sR.h = 25;
      if(invencible > 0) {
        sR.x = 100;
      }
    }
    if(sentido == 'c') {
      sR.x = 4 + 24*move; sR.y = 70; sR.w = 16; sR.h = 25;
      if(invencible > 0) {
        sR.x = 100 + 24*move;
      }
    }
    if(sentido == 'd') {
      sR.x = 53 + 23*move; sR.y = 38; sR.w = 16; sR.h = 25;
      if(invencible > 0) {
        sR.x = 149 + 24*move;
      }
    }
    else if(sentido == 'e') {
      sR.x = 5 + 24*move; sR.y = 38; sR.w = 16; sR.h = 25;
      if(invencible > 0) {
        sR.x = 101 + 24*move;
      }
    }
  }
  contador++;
  rR.x = gX - rRcam.x; rR.y = gY - rRcam.y; rR.w = 32; rR.h = 50;
  //MOVIMENT DO PLAYER//;
  SDL_RenderCopy(render, playerTex, &sR, &rR);
}

bool renderizar(void) {
  //RECT CAMERA//
  rRcam.x = gX - 320;
  rRcam.y = gY - 200;
  if(rRcam.x < 0) {
    rRcam.x = 0;
  }
  if(rRcam.y < 0){
    rRcam.y = 0;
  }
  if(rRcam.x + rRcam.w >= mapw) {
    rRcam.x = mapw - 640;
  }
  if(rRcam.y + rRcam.h >= maph) {
    rRcam.y = maph - 400;
  } 
  // HUD configs //
      //heart//
  SDL_Rect sH = {0,11 * life,43,11};
  rH.x = 10; rH.y = 10; rH.w = 129 ;rH.h = 33;
  
  //RECT do MONSTRO//
  SDL_Rect sRm = {0,0,32,32};
  rRm[0].x = gXm[0] + 200 - rRcam.x; rRm[0].y = gYm[0] + 80 - rRcam.y; rRm[0].w = rng; rRm[0].h = rng;
  rRm[1].x = gXm[1] + 500 - rRcam.x; rRm[1].y = gYm[1] + 700 - rRcam.y; rRm[1].w = rng; rRm[1].h = rng;
  rRm[2].x = gXm[2] + 800 - rRcam.x; rRm[2].y = gYm[2] + 200 - rRcam.y; rRm[2].w = rng; rRm[2].h = rng;
  rRm[3].x = gXm[3] + 300 - rRcam.x; rRm[3].y = gYm[3] + 900 - rRcam.y; rRm[3].w = rng; rRm[3].h = rng;
  //RECT do Wall//
  SDL_Rect sRw = {0,0,32,32};
  rRw[0].x = 0 - rRcam.x; rRw[0].y = 0 - rRcam.y; rRw[0].w = 32; rRw[0].h = 100; //WALL CANTO ESQUERDO //
  rRw[1].x = 1920-32 - rRcam.x; rRw[1].y = 0 - rRcam.y; rRw[1].w = 32; rRw[1].h = 200; // WALL CANTO DIREITO //
  rRw[2].x = 0 - rRcam.x; rRw[2].y = 0 - rRcam.y; rRw[2].w = 1920; rRw[2].h = 32; // WALL CIMA //
  rRw[3].x = 0 - rRcam.x; rRw[3].y = 64 - rRcam.y; rRw[3].w = 100; rRw[3].h = 300; // WALL BAIXO // 
  
  //Renderizar mapas e acoes//
  SDL_RenderClear(render);
  //MAPA//
  SDL_RenderCopy(render, mapTex, &rRcam, NULL);
  //MOVIMENT DOS MONSTROS//
  for(int i = 0; i < 4; i++)
    SDL_RenderCopy(render, monsterTex, &sRm, &rRm[i]);
  //RENDER DO WALL//
  for(int i = 0; i < 4; i++)
    SDL_RenderCopy(render, wallTex, &sRw, &rRw[i]);
  //MOVIMENT DO PLAYER//
  playerAnimated();
  //HUD//
  SDL_RenderCopy(render, heartTex, &sH, &rH);
  //PRESENT
  SDL_RenderPresent(render);  
}
void invencibleF (void) {
  //INVENCIBILIDADE DO JOGADOR APOS A COLISAO COM MOB//
  if(invencible == 1) {
    printf("[Console]Tempo de Invencibilidade Iniciado! %i Vidas!\n", life);
    invencible++;
  }
  else if(invencible > 1 && invencible <= 40) {
    invencible++;
  }
  else if(invencible > 40) {
    invencible = 0; 
    printf("[Console]Tempo de Invencibilidade Finalizado!\n");
  }
}
void knockb(void) {
  //colisao direita//
  if(kback == 1) /*direita*/ {
    printf("[Console]O Jogador foi atirado para direita!\n");
    kbacktime = 1;
    mobwaiting = 1;
    kback = 0;
  }
  if(kbacktime > 0 && kbacktime <= 15) {
    for(int i = 0; i < 4; i++) { //COLIDINDO COM WALL//
      colisao = collision(rR.x + 15, rR.y, rR.w, rR.h, rRw[i].x, rRw[i].y, rRw[i].w, rRw[i].h);
    }
      if(!colisao)
        gX += (vel*2);
    kbacktime++;
  }
  if(kbacktime > 15) {
    kbacktime = 0;
    printf("[Console]O Jogador deixou de ser atirado para direita!\n");
  }
  //colisao esquerda//
  if(kback == -1) /*direita*/ {
  printf("[Console]O Jogador foi atirado para esquerda!\n");
    kbacktime = -1;
    mobwaiting = 1;
    kback = 0;
  }
  if(kbacktime < 0 && kbacktime >= -15) {
    for(int i = 0; i < 4 || colisao; i++) { //COLIDINDO COM WALL//
      colisao = collision(rR.x + 15, rR.y, rR.w, rR.h, rRw[i].x, rRw[i].y, rRw[i].w, rRw[i].h);
    }
    if(!colisao)
        gX -= (vel*2);
    kbacktime--;
  }
  if(kbacktime < -15) {
    kbacktime = 0;
    printf("[Console]O Jogador deixou de ser atirado para esquerda!\n");
  }
  //MOBWAITING// 
  if(mobwaiting > 0 && mobwaiting <= maxmobwaiting){
    mobwaiting++;
  }
}
                                                                                                                      // MAIN // 
int main (void) {
  //INICIANDO SDL//
  SDL_Init(SDL_INIT_EVERYTHING);
  Mix_OpenAudio(MIX_DEFAULT_FREQUENCY, MIX_DEFAULT_FORMAT, 2, 4096);
  Mix_Volume(1, 20);
  //START PLAYER//
  rR.x = gX; rR.y = gY; rR.w = 64; rR.h = 120;
  //FRAMETIME//
  const int FPS = 60;
  const int frameDelay = 1000/ FPS;
  int frameStart;
  int frameTime;
  //Start em Window//
  if(!janela()) {
    printf("A TELA NÃO INICIOU!");
  }
  else{
    //GAME HERE//
    printf("[Console]tela iniciada\n");
    surfaces();
    printf("[Console]surfaces carregadas\n");
    audio();
    printf("[Console]audio iniciado\n");
    printf("[Console]o Jogo ira iniciar...\n");
    printf(". ");
    printf(". ");
    printf(".\n");
    printf("[Console]iniciando!\n");
    Mix_PlayChannel(1, welcome, 0);
    while(gaming) {                
      Mix_PlayMusic(fight, -1);                                                                                             //GAME LOOP//
      //FRAMES//
        frameStart = SDL_GetTicks();
      //Eventos//
      while(SDL_PollEvent(&event)){
        //X to close//
        if (event.type == SDL_QUIT)
          gaming = false;
        //reconhecendo movimentos//
        movements();
      }
      // RESCALAR JANELA E SPRITES //
      rescalar();
      SDL_RenderSetLogicalSize(render, 640, 400);
      // dando movimentos //
          makemovements();
      // movimentos dos mobs //
      for(int i = 0; i < numMobs; i++)
        lixo = mob(i, colisao);
      // COLISORES //
      //PLAYER -> WALL//
      for(int i = 0; i < numWall; i++) { 
        colisao = collision(rR.x, rR.y, rR.w, rR.h, rRw[i].x, rRw[i].y, rRw[i].w, rRw[i].h);
        if(colisao) {
          collision2(rR.x, rR.y, rR.w, rR.h, rRw[i].x, rRw[i].y, rRw[i].w, rRw[i].h, vel);
        }
      }
      // PLAYER -> MOB//
      for(int i = 0; i < numMobs && invencible == 0; i++) { 
        colisao = collision(rR.x, rR.y, rR.w, rR.h, rRm[i].x, rRm[i].y, rRm[i].w, rRm[i].h);
        if(mobwaiting == maxmobwaiting) {
          andando[idAndando] = tempAndando[idAndando];
          mobwaiting = 0;
        }
        if(colisao) {
          Mix_PlayChannel(1, damage, 0);
          if(invencible == 0) {
            kback = collisionMob(rR.x, rR.y, rR.w, rR.h, rRm[i].x, rRm[i].y, rRm[i].w, rRm[i].h, mob(i, colisao));
            if(mobwaiting == 0) {
              tempAndando[i] = andando[i];
              andando[i] *= -1;
              idAndando = i;
            }
          }
          //printf("O Jogador Colidiu Com Um Monstro!\n");
          if(life >= 0 && invencible == 0) {
            life--;
            invencible = 1;
          }
        }
      }
      invencibleF();
      //KNOCKBACK//
      knockb();
      // APRESENTANDO AO USUARIO //
      renderizar();
      //morte//
      if(life < 0 && invencible == 0) {
            gaming = false;
            Mix_PlayChannel(1, death, 0);
            SDL_Delay(1000);
            printf("\n\n\n[Console]Voce Perdeu, Meu Consagrado! \n\n\n");
          }
      //FRAME DELAY//
      frameTime = SDL_GetTicks() - frameStart;
      if(frameDelay > frameTime) {
        SDL_Delay(frameDelay - frameTime);
      }
    }
    

    //teladeAnimacao();

  }
  //Destroy//
  SDL_DestroyWindow(gJanela);
  SDL_DestroyTexture(playerTex);
  SDL_DestroyTexture(monsterTex);
  SDL_DestroyTexture(wallTex);
  SDL_DestroyTexture(mapTex);
  SDL_DestroyTexture(heartTex);
  //FIM//
  Mix_Quit();
  SDL_Quit();   
}

void teladeAnimacao (void) {
    SDL_RenderClear(render);
    for(int i = 0; i <= 100; i++) {
        SDL_RenderCopy(render, mapTex, &rRcam, NULL);
        SDL_RenderPresent(render);
        SDL_Delay(1000/60);
    }
    for(int i = 255; i >= 0; i--) {
        SDL_RenderCopy(render, mapTex, &rRcam, NULL);
        SDL_SetRenderDrawColor(render, 0, 0, 0, i);
        SDL_RenderPresent(render);
        SDL_Delay(1000/60);
    }
}