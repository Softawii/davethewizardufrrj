#include <SDL2/SDL.h>

int main (void) {
	SDL_Init(SDL_INIT_EVERYTHING);
	printf("absolutamente uma vitoria\n");
	SDL_Quit();

}