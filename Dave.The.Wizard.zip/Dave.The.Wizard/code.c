//MINI BOSS SLIME EM DESENVOLVIMENTO! //
#include <time.h>
#include <stdio.h> // FUNCOES BASICAS // se necessario
#include <stdlib.h>
#include <stdbool.h> // BOOLEANAS //
#include <math.h> // matematica top /
#include <time.h>
#include "SDL2/SDL.h" //SDL LIBRARY //
#include "SDL2/SDL_image.h"
#include "SDL2/SDL_mixer.h"
#include "SDL2/SDL_ttf.h"

// BIBLIOTECAS PROPRIAS //
#include "headers/colisor.h"
#include "headers/knockback.h"
#include "headers/meatbox.h"
#include "headers/ogre.h"
#include "headers/explosion.h"
#include "headers/mage.h"
#include "headers/player.h"
#include "headers/cristal.h"

#define LIFE 5
#define LIFEMOB1 3
#define DELAY_PROJETIL 60
#define SENTINELAPROJETIL 2

//test//
SDL_Rect temp;
//VARIAVEIS, SURFACES, ETC//
int sala=1, checkSala = 1;
int w=1280,h=800;
bool gaming = true; //GAME LOOP//
//int gX = 318, gY = 120; //MOVIMENTAÇÃO//
float gX = 407, gY = 102; //MOVIMENTAÇÃO//
int xd,xe,yb,yc; //VARIAVEIS EXTRAS//

//COLISOES//
bool colisao = false;
//MAP//
SDL_Rect rRcam = {0,0,640, 400};
SDL_Texture* mapTex; //textura da wall//
SDL_Surface* mapSurf; //surface da wall//
SDL_Texture* mapTex2; //textura da wall//
SDL_Surface* mapSurf2; //surface da wall//
int mapw = 1440;
int maph = 1200;
//interactives blocks//
SDL_Texture* interactiveTex;
SDL_Surface* interactiveSurf; 
SDL_Rect sCaixa[1] = {0,0,8,12};
SDL_Rect rCaixa[1];
int numPortas = 1;
SDL_Rect sPorta[1] = {9,0,15,12};
SDL_Rect rPorta[1];
int caixax[1] = {950};
int caixay[1] = {200};
bool porta[1] = {true};
//WALL//
SDL_Rect rRw[51];
SDL_Texture* wallTex; //textura da wall//
SDL_Surface* wallSurf; //surface da wall//
int numWall = 51;

//canhao brabo top das galaxias// 
// obs:. AGORA QUE EU APRENDO STRUCT EU FICO PISTOL MANO NAMORAL SEI DE NADA NAO
// NAO VOU REFAZER METADO DO MEU CÓDIGO PRA FAZER STRUCT ENTÃO MEU CARO LEITOR SE VC SE INCOMODOU
// TENHO UMA PALAVRA PRA VC..... CAGUEI........... fim de transmissão bip BIP //
SDL_Texture* cannonTex; // textura do canhao top lindo//
SDL_Surface* cannonSurf; // surface do canhao trash feio //
//SDL_Rect sCanhao = {0 + 22*sentidoc, 0, 22, 23};
SDL_Rect sProjetilc = {96, 9, 6, 6};
struct CANHAO {
  int espera; // tempo de espera entre os tiros//
  int contador; // conta o tempo de espera//
  int velocidade; // velocidade do tiro do projetil //
  int sentidoc; // direita = 0// esquerda = 1// cima = 2// baixo = 3//
  int x;
  int y;
  int movimento;
  SDL_Rect sCanhao;
  SDL_Rect rCanhao;
  SDL_Rect rProjetil;
};
typedef struct CANHAO CANHAO;
CANHAO canhoes[4]; // quantidade de canhoes nesse mapa de merda valeu falou :dedaopracima:
int numCanhoes = 4;
//struct top de baus com intens maneiros//
struct CHEST {
  bool estado;
  int x;
  int y;
  SDL_Rect pos;
};
typedef struct CHEST CHEST;
CHEST chest[1];
int numChest = 1;
SDL_Rect sChestF = {0,0, 32, 32};
SDL_Rect sChestA = {32, 0, 32, 32};
SDL_Surface* chestSurf;
SDL_Texture* chestTex;


// MINI BOSS//
SDL_Surface* minibossSurf;
SDL_Texture* minibossTex;
struct MINIBOSS {
  SDL_Rect posTela;
  SDL_Rect posCorte;
  int life;
  int velocidade;
  int posicaox;
  int posicaoy;
  int direcao;
  int andando;
  bool sala;
};
typedef struct MINIBOSS MINIBOSS;
MINIBOSS miniboss[1];
SDL_Rect rBossBar = {212,370, 217, 12};
SDL_Rect sBossBar = {0, 0, 217, 12};
SDL_Rect rBossLife;
SDL_Rect sBossLife = {220, 1, 9, 9};

// MEAT BOX //
SDL_Surface* meatboxSurf;
SDL_Texture* meatboxTex;
MEATBOX meatbox[3];
int meatboxMobs = 3;

// OGRE //
SDL_Surface* ogreSurf;
SDL_Texture* ogreTex;
OGRE ogre[4];
int ogreMobs = 4;

// MAGE //

MAGE mage[2];
SDL_Surface* mageSurf;
SDL_Texture* mageTex;
int mageMobs = 2;

// EXPLOSION //
MEGUMIN explodir;
SDL_Surface* explodirSurf;
SDL_Texture* explodirTex;

// CRISTAL //
SDL_Surface* cristalSurf;
SDL_Texture* cristalTex;
CRISTAL cristal[4];
static int cristalQuantidade = 4;

// MOUSE //
PONTEIROMOUSE mouse;
SDL_Cursor* cursor;
SDL_Surface* colorCursor;

// MISSAO //
DESAFIOS missao;

// PORTAO //
SDL_Surface* portaoSurf;
SDL_Texture* portaoTex;
PORTAO portao;

//PLAYER//
SDL_Rect rR;
SDL_Rect sR;
SDL_Texture* playerTex; //textura do Personagem
SDL_Surface* playerSurf; //Surface do Player
SDL_Texture* objectTex; //textura de objtos//
SDL_Surface* objectSurf; // surface de objetos//
int life = LIFE; //VIDA DO PLAYER//
int coins = 0;
int invencible = 0; //INVENCIBILIDADE DE DANO//
KBACK kback; 
float const vel = 2.1; // VELOCIDADE DO PLAYER //
char sentido = 'b';
bool cajado = true; //se esta equipando o cajado magico topzudo//
bool interagir = false; // se estamos interagindo com algum item maneiro //
bool regeneffect = false;
bool regeneffectkeydown = false;
bool projetilstop;
  //cajado//
bool projetil = false;
SDL_Rect rProjetil;
SDL_Rect sProjetil;
SDL_Rect rProjetilPoder = {640-84, 2, 42, 43.5};
SDL_Rect sProjetilPoder = {0, 0, 28, 29};
SDL_Rect siconCajado = {0,0,16,16};
SDL_Rect riconCajado;
SDL_Surface * cajadoSurf;
SDL_Texture * cajadoTex;
CAJADO staff;
SDL_Point centerstaff;
//hud//
SDL_Rect rH; //rect HUD//
SDL_Texture* heartTex; //textura do Personagem
SDL_Surface* heartSurf; //Surface do Player
SDL_Texture* HUDTex; // textura dos huds*//
SDL_Surface* HUDSurf; // surface dos huds//
// pocao //
SDL_Rect siconPotion = {28, 0, 28, 29};
SDL_Rect riconPotion = {1, 370, 28,29};
int chaves = 0;
int potion = 2;  
// CAIXAS DE DIALOGO//
SDL_Surface* dialogboxSurf;
SDL_Texture* dialogboxTex;
SDL_Rect sDialogBox = {1,2,539, 114};
SDL_Rect rDialogBox = {50,280, 539, 114}; 
bool emDialogo = false;


SDL_Surface* fadeSurf;//fade in-out surface//
SDL_Texture* fadeTex;
int fadeAlpha = 0;

SDL_Window* gJanela = NULL; // CRIANDO JANELA //

SDL_Renderer* render;// Render da Screen //

SDL_Event event; //LER EVENTOS//

//AUDIO//
Mix_Chunk* damage;
Mix_Chunk* death;
Mix_Chunk* hitwall;
Mix_Chunk* welcome;
Mix_Chunk* projetilhit;
Mix_Chunk* projetilstart;
Mix_Chunk* projetilend;
Mix_Chunk* walk;
Mix_Chunk* warning;
Mix_Chunk* cannon;
Mix_Chunk* regen;
Mix_Chunk* interactioneffect;
Mix_Chunk* error;
Mix_Chunk* openchest;
Mix_Chunk* killenemys;
Mix_Chunk* cristalsounds;
Mix_Chunk* opendoor;
Mix_Music* fightmusic;


//fonte//
SDL_Rect textRect = {30,375, 100, 500};
TTF_Font* fonte;
SDL_Surface* fontePote;
SDL_Surface* fonteDialogo;
SDL_Color cor = {255,255,255}; // branco como a neve //
SDL_Texture* text[10];
char numerodepocoes[5] = "10";


//CHAMADA//
bool janela (void);
void surfaces (void);
bool renderizar(void);
void renderizarBaus(void);
bool rescalar(void);
void movements (void);
void makemovements(void);
void teladeAnimacaoIN (void);
void teladeAnimacaoOUT (void);
int mob (int i, bool colid, SDL_Rect r1);
void teladeAnimacao (void);
bool collision(SDL_Rect r1, SDL_Rect r2, int velocidadex, int velocidadey);
void salaCamera();
void salaAtual();
void slimeAnimated(int i);
void interaction(void);
void blocksinteractive(void);
void verificator(void);
bool wall_agua(int i);
void renderizarparedes(void);
void iniciarCanhoes (void);
void player_canhao(void);
void regenerar(void);
void fontes(void);
void alterarfonte(int i);
void renderizarMiniBoss(void);
// FUNCOES //
                                                                               //INICIAÇÃO//
                                                                               
//PLAYERSTART//
void playerStart (void) {
  kback.mobNUMERO = 0; // NUMERO DO MOB //
  kback.mobTYPE = 'M'; // M = MEATBOX //
  kback.emKBACK = false;

  rProjetil.x = -5000;
  rProjetil.y = -5000;
  missao.desafiomatarportempo = false;

  staff.sR.x = 0; staff.sR.y = 0; staff.sR.w = 8; staff.sR.h = 30;
  staff.rR.x = 0; staff.rR.y = 0; staff.rR.w = 16; staff.rR.h = 60;

  portao.x = 672; portao.y = 504;
  portao.contador = 0;

}
// CRISTAL START //
void cristalStart (void) {
  cristal[0].contadorrgb = 0; cristal[0].contadoranime = 0;
  cristal[0].x = 532; cristal[0].y = 607; cristal[0].ativo = true; // cristal da de baixo

  cristal[1].contadorrgb = 0; cristal[1].contadoranime = 0;
  cristal[1].x = 1033; cristal[1].y = 173; cristal[1].ativo = true; //cristal la de cima

  cristal[2].contadorrgb = 0; cristal[2].contadoranime = 0;
  cristal[2].x = 820; cristal[2].y = 183; cristal[2].ativo = true; // cristal do meio

  cristal[3].contadorrgb = 0; cristal[3].contadoranime = 0; 
  cristal[3].x = 480; cristal[3].y = 202; cristal[3].ativo = true;   // cristal cima esquerda
}

// INIICAR MAGE //
void mageStart (void) {
  // MAGE 0 //
  if(cristal[1].ativo) {
    mage[0].life = 1; mage[0].distancia = 900; mage[0].delay = 90; mage[0].dir = false;
    mage[0].i = 0; mage[0].morrer = 0; mage[0].damage = 3; mage[0].x = 975;
    mage[0].y = 200; mage[0].xp = mage[0].x; mage[0].y; mage[0].yp = mage[0].y;
    mage[0].velmx = 0; mage[0].velmy = 0; mage[0].j = 0; mage[0].espera = 0;
  }
  // MAGE 1//s
  if(cristal[3].ativo) {
    mage[1].life = 1; mage[1].distancia = 900; mage[1].delay = 90; mage[1].dir = false;
    mage[1].i = 0; mage[1].morrer = 0; mage[1].damage = 3; mage[1].x = 488;
    mage[1].y = 358; mage[1].xp = mage[1].x; mage[1].y; mage[1].yp = mage[1].y;
    mage[1].velmx = 0; mage[1].velmy = 0; mage[1].j = 0; mage[1].espera = 0;
  }
  printf("[Console]OS MAGOS IRAO QUEIMAR SUA ALMA!\n");
}
// INICIAR MEATBOX //
void meatboxStart (void) {
  // MEATBOX 0 //
  if(cristal[0].ativo) {
    meatbox[0].life = 3; meatbox[0].velocidade = 1.5; meatbox[0].distancia = 450; meatbox[0].i = 0;
    meatbox[0].x = 510; meatbox[0].y = 818; meatbox[0].agressivo = false; meatbox[0].espera = 1;
    meatbox[0].sR.w = 23;meatbox[0].sR.h = 34; meatbox[0].sR.y = 0; meatbox[0].dir = true; meatbox[0].damage = 2;
    meatbox[0].contador = 0; meatbox[0].maximo = 60; meatbox[0].delay = 0; meatbox[0].morrer = 0; meatbox[0].seguir = 1;
  }
  // meatbox 1 //
  if(cristal[0].ativo) {
    meatbox[1].life = 3; meatbox[1].velocidade = 1.5; meatbox[1].distancia = 450; meatbox[1].i = 0;
    meatbox[1].x = 830; meatbox[1].y = 830; meatbox[1].agressivo = false; meatbox[1].espera = 1;
    meatbox[1].sR.w = 23;meatbox[1].sR.h = 34; meatbox[1].sR.y = 0; meatbox[1].dir = true; meatbox[1].damage = 2;
    meatbox[1].contador = 0; meatbox[1].maximo = 60; meatbox[1].delay = 0; meatbox[1].morrer = 0; meatbox[1].seguir = 1;
  }
  // meatbox 2 //
  printf("[Console] MEATBOX PRONTO PARA MATAR!\n");
}
// INICIAR OGRE //
void ogreStart (void) {
  // OGRE 0 //
  if(cristal[2].ativo) {
    ogre[0].life = 1; ogre[0].velocidade = 2; ogre[0].troca = false; ogre[0].direct = 1; ogre[0].dir = false;
    ogre[0].damage = 1; ogre[0].x = 554; ogre[0].y = 169; ogre[0].espera = 1; ogre[0].maximo = 60; 
    ogre[0].i = 0; ogre[0].delay = 1; ogre[0].loop = 1; ogre[0].danodelay = 0; ogre[0].morrer = 0;
  }
  // OGRE 1 //
  if(cristal[2].ativo) {
    ogre[1].life = 1; ogre[1].velocidade = 2; ogre[1].troca = false; ogre[1].direct = 1; ogre[1].dir = false;
    ogre[1].damage = 1; ogre[1].x = 942; ogre[1].y = 233; ogre[1].espera = 1; ogre[1].maximo = 60; 
    ogre[1].i = 0; ogre[1].delay = 1; ogre[1].loop = 1; ogre[1].danodelay = 0; ogre[1].morrer = 0;
  }
  // OGRE 2 //
  if(cristal[2].ativo) {
    ogre[2].life = 1; ogre[2].velocidade = 2; ogre[2].troca = false; ogre[2].direct = 1; ogre[2].dir = false;
    ogre[2].damage = 1; ogre[2].x = 1129; ogre[2].y = 796; ogre[2].espera = 1; ogre[2].maximo = 60; 
    ogre[2].i = 0; ogre[2].delay = 1; ogre[2].loop = 1; ogre[2].danodelay = 0; ogre[2].morrer = 0;
  }
  // OGRE 3 //
  if(cristal[2].ativo) {
    ogre[3].life = 1; ogre[3].velocidade = 2; ogre[3].troca = false; ogre[3].direct = 1; ogre[3].dir = false;
    ogre[3].damage = 1; ogre[3].x = 429; ogre[3].y = 386; ogre[3].espera = 1; ogre[3].maximo = 60; 
    ogre[3].i = 0; ogre[3].delay = 1; ogre[3].loop = 1; ogre[3].danodelay = 0; ogre[3].morrer = 0;
  }
  printf("[Console] OGROS AO ATAQUE!\n");
}
void iniciarChests (void) {
  // chest 1 //
  chest[0].estado = true;
  chest[0].x = 384;
  chest[0].y = 55;
  chest[0].pos.x = chest[0].x - rRcam.x; chest[0].pos.y = chest[0].y - rRcam.y;
  chest[0].pos.w = 32; chest[0].pos.h = 32;
  //char chest[0].texto[100] = "Oi";
  // fim chest 1 //
}
void iniciarCanhoes (void){
  //CANHAO 1 ! ! ! ! ! ! ! ! ! ! ! !//
  canhoes[0].espera = 120; canhoes[0].contador = 0; canhoes[0].velocidade = 4; canhoes[0].movimento = 0;
  canhoes[0].sentidoc = 3; canhoes[0].x = 703; canhoes[0].y = 111;
  // pegando o rect do canhao//
  canhoes[0].sCanhao.x = 0 + 22*canhoes[0].sentidoc; canhoes[0].sCanhao.y = 0; 
  canhoes[0].sCanhao.w = 22; canhoes[0].sCanhao.h = 23;
  //posicao do canhao//
  canhoes[0].rCanhao.x = canhoes[0].x - rRcam.x; canhoes[0].rCanhao.y = canhoes[0].y - rRcam.y; 
  canhoes[0].rCanhao.w = 44; canhoes[0].rCanhao.h = 46;
  // posicao inicial do projetil :p//
  canhoes[0].rProjetil.x = canhoes[0].x + 12 - rRcam.x; canhoes[0].rProjetil.y =  canhoes[0].y + 10 - rRcam.y;
  canhoes[0].rProjetil.w = 12; canhoes[0].rProjetil.h = 12;
}
/*
void renderizarMiniBoss(void) {
  //printf("I,m here\n");

  if(rR.x >= 6 - rRcam.x && rR.x <= 1270 - rRcam.x && 
    rR.y >= 733 - rRcam.y && rR.y <= 1193 - rRcam.y && miniboss[0].life > 0) {
    miniboss[0].sala = true;
    //printf("I,m here\n");
    rBossLife.x = rBossBar.x + 4; rBossLife.y = rBossBar.y + 1;
    //PARTE SUJEITA A MUDANCAS//
    rBossLife.w = lifemob[8] * 14; rBossLife.h = 9;
    //renderizar();
    SDL_RenderCopy(render, minibossTex, &sBossLife, &rBossLife);
    SDL_RenderCopy(render, minibossTex, &sBossBar, &rBossBar);
  }
  else {
    miniboss[0].sala = false;
  }
}
*/
void fontes(void){
  static const int FONTSIZE = 9;
  fonte = TTF_OpenFont("fontes/fontetop.ttf", FONTSIZE);
  fontePote = TTF_RenderText_Solid(fonte, numerodepocoes, cor);
  text[0] = SDL_CreateTextureFromSurface(render, fontePote);
  SDL_QueryTexture(text[0], NULL, NULL, &textRect.w, &textRect.h);
  //SDL_BlitSurface(fontePote, NULL, render, NULL);
  SDL_FreeSurface(fontePote);
}
void alterarfonte(int i){
  sprintf(numerodepocoes, "%d", potion);
  fontePote = TTF_RenderText_Solid(fonte, numerodepocoes, cor);
  text[i] = SDL_CreateTextureFromSurface(render, fontePote);
  SDL_QueryTexture(text[i], NULL, NULL, &textRect.w, &textRect.h);
}
void audio(void) {
  damage = Mix_LoadWAV("sfx/damage.wav");
  death = Mix_LoadWAV("sfx/death.wav");
  hitwall = Mix_LoadWAV("sfx/hitwall.wav");
  welcome = Mix_LoadWAV("sfx/welcome.wav");
  projetilhit = Mix_LoadWAV("sfx/projetilhit.wav");
  projetilstart = Mix_LoadWAV("sfx/projetilstart.wav");
  projetilend = Mix_LoadWAV("sfx/projetilend.wav");
  walk = Mix_LoadWAV("sfx/walk.wav");
  warning = Mix_LoadWAV("sfx/warning.wav");
  cannon = Mix_LoadWAV("sfx/cannon.wav");
  error = Mix_LoadWAV("sfx/error.wav");
  regen = Mix_LoadWAV("sfx/regen.wav");
  interactioneffect = Mix_LoadWAV("sfx/interaction.wav");
  openchest = Mix_LoadWAV("sfx/openchest.wav");
  fightmusic = Mix_LoadMUS("songs/fight.mp3");
  killenemys = Mix_LoadWAV("sfx/killenemys.wav");
  cristalsounds = Mix_LoadWAV("sfx/cristal.wav");
  opendoor = Mix_LoadWAV("sfx/opendoor.wav");
}
void surfaces (void) {
                                                                   //Gerando Texturas e Sprites do Player//
  // CURSOR //
  colorCursor = IMG_Load("sprites/pointer.png");
  cursor = SDL_CreateColorCursor(colorCursor, 0, 0);
  //cursor = SDL_CreateSystemCursor(SDL_SYSTEM_CURSOR_CROSSHAIR);
  SDL_SetCursor(cursor);
  //PLAYER SPRITES//
  playerSurf = IMG_Load("sprites/char.png");
  playerTex = SDL_CreateTextureFromSurface(render, playerSurf);
  SDL_FreeSurface(playerSurf);
  //WALL//
  wallSurf = IMG_Load("sprites/wall.png");
  wallTex = SDL_CreateTextureFromSurface(render, wallSurf);
  SDL_FreeSurface(wallSurf);
  //MAP//
  mapSurf = IMG_Load("img/world.png");
  mapTex = SDL_CreateTextureFromSurface(render, mapSurf);
  SDL_QueryTexture(mapTex, NULL, NULL, &mapw, &maph);
  SDL_FreeSurface(mapSurf);
  //MAP//
  mapSurf2 = IMG_Load("img/worldobject.png");
  mapTex2 = SDL_CreateTextureFromSurface(render, mapSurf2);
  SDL_QueryTexture(mapTex2, NULL, NULL, &mapw, &maph);
  SDL_FreeSurface(mapSurf2);
  //HEART//
  heartSurf = IMG_Load("sprites/hud_heart.png");
  heartTex = SDL_CreateTextureFromSurface(render, heartSurf);
  SDL_FreeSurface(heartSurf);
  //FADE//
  fadeSurf = IMG_Load("img/fade.png");
  fadeTex = SDL_CreateTextureFromSurface(render, fadeSurf);
  SDL_FreeSurface(fadeSurf);
  //OBJETOS//
  objectSurf = IMG_Load("sprites/objetos.png");
  objectTex = SDL_CreateTextureFromSurface(render, objectSurf);
  SDL_FreeSurface(objectSurf);
  //HUD ITENS//
  HUDSurf = IMG_Load("sprites/icon.png");
  HUDTex = SDL_CreateTextureFromSurface(render, HUDSurf);
  SDL_FreeSurface(HUDSurf);
  //OBJETOS INTERATIVOS//
  interactiveSurf = IMG_Load("sprites/interactive.png");
  interactiveTex = SDL_CreateTextureFromSurface(render, interactiveSurf);
  SDL_FreeSurface(interactiveSurf);
  //CANHAO//
  cannonSurf = IMG_Load("sprites/cannon.png");
  cannonTex = SDL_CreateTextureFromSurface(render, cannonSurf);
  SDL_FreeSurface(cannonSurf);
  //bau
  chestSurf = IMG_Load("sprites/chest.png");
  chestTex = SDL_CreateTextureFromSurface(render, chestSurf);
  SDL_FreeSurface(chestSurf);
  // MINIBOSS//
  minibossSurf = IMG_Load("sprites/bossbar.png");
  minibossTex = SDL_CreateTextureFromSurface(render, minibossSurf);
  SDL_FreeSurface(minibossSurf);
  // baixas de dialogo//
  dialogboxSurf = IMG_Load("sprites/dialogbox.png");
  dialogboxTex = SDL_CreateTextureFromSurface(render, dialogboxSurf);
  SDL_FreeSurface(dialogboxSurf);
  // MEAT BOX //
  meatboxSurf = IMG_Load("sprites/meatbox.png");
  meatboxTex = SDL_CreateTextureFromSurface(render, meatboxSurf);
  SDL_FreeSurface(meatboxSurf);
  // OGRE //
  ogreSurf = IMG_Load("sprites/ogre.png");
  ogreTex = SDL_CreateTextureFromSurface(render, ogreSurf);
  SDL_FreeSurface(ogreSurf);
  // EXPLOSION //
  explodirSurf = IMG_Load("sprites/explosion.png");
  explodirTex = SDL_CreateTextureFromSurface(render, explodirSurf);
  SDL_FreeSurface(explodirSurf);
  // MAGE//
  mageSurf = IMG_Load("sprites/mage.png");
  mageTex = SDL_CreateTextureFromSurface(render, mageSurf);
  SDL_FreeSurface(mageSurf);
  // cajado//
  cajadoSurf = IMG_Load("sprites/cajado.png");
  cajadoTex = SDL_CreateTextureFromSurface(render, cajadoSurf);
  SDL_FreeSurface(cajadoSurf);
  // cristal //
  cristalSurf = IMG_Load("sprites/cristais.png");
  cristalTex = SDL_CreateTextureFromSurface(render, cristalSurf);
  SDL_FreeSurface(cristalSurf);
  // portao //
  portaoSurf = IMG_Load("sprites/portao.png");
  portaoTex = SDL_CreateTextureFromSurface(render, portaoSurf);
  SDL_FreeSurface(portaoSurf);
}
/*
sprintf(numerodepocoes, "%d", potion);
  fontePote = TTF_RenderText_Solid(fonte, numerodepocoes, cor);
  text[0] = SDL_CreateTextureFromSurface(render, fontePote);
  SDL_QueryTexture(text[0], NULL, NULL, &textRect.w, &textRect.h);
"Voce recebeu duas pocoes! Clique 'alt' para continuar!"

*/
void abrirDialogbox (char texto[]) {
  bool acabou = false;
  SDL_Rect posicaoText = {rDialogBox.x + 10, rDialogBox.y + 10, rDialogBox.w, rDialogBox.h};

  fonteDialogo = TTF_RenderText_Solid(fonte, texto, cor);
  text[1] = SDL_CreateTextureFromSurface(render, fonteDialogo);
  SDL_QueryTexture(text[1], NULL, NULL, &posicaoText.w, &posicaoText.h);
  SDL_FreeSurface(fonteDialogo);
  // mini loop//
  while(!acabou){
    emDialogo = true;
    renderizar();
    SDL_RenderCopy(render, dialogboxTex, &sDialogBox, &rDialogBox);
    SDL_RenderCopy(render, text[1], NULL, &posicaoText);
    SDL_RenderPresent(render);
    //printf("eu estive aq!\n");
    while(SDL_PollEvent(&event)){
        //X to close//
        if(event.type == SDL_KEYDOWN && event.key.keysym.sym == SDLK_LALT)
         acabou = true;
    }
    SDL_Delay(1000/60);
  }
  emDialogo = false;
}
void renderizarCanhoes (void) {
  for(int i = 0; i < numCanhoes; i++) {
    canhoes[i].rCanhao.x = canhoes[i].x - rRcam.x; 
    canhoes[i].rCanhao.y = canhoes[i].y - rRcam.y;
  }
  // posicao do projetil :p//
  for(int i = 0; i < numCanhoes; i++) {
    if(canhoes[i].contador < canhoes[i].espera && !emDialogo) {
      if(canhoes[i].contador == 0 && 
        sqrt(pow(rR.x + rR.w - canhoes[i].rCanhao.x,2) + pow(rR.y + rR.h - canhoes[i].rCanhao.y,2)) <= 600) {
        Mix_PlayChannel(1, cannon, 0);
      } // essa parte faz um som-zinho maneiro hehe :happy: // 
      if(canhoes[i].sentidoc == 0 && canhoes[i].contador <= 90) { // direita //
        canhoes[i].movimento += canhoes[i].velocidade;
        canhoes[i].rProjetil.y = canhoes[i].y - rRcam.y;
        canhoes[i].rProjetil.x = canhoes[i].x - rRcam.x + canhoes[i].movimento;
        canhoes[i].contador++;
      }
      else if(canhoes[i].sentidoc == 1 && canhoes[i].contador <= 90) { // esquerda //
        canhoes[i].movimento -= canhoes[i].velocidade;
        canhoes[i].rProjetil.y = canhoes[i].y - rRcam.y;
        canhoes[i].rProjetil.x = canhoes[i].x - rRcam.x + canhoes[i].movimento;
        canhoes[i].contador++;
      }
      else if(canhoes[i].sentidoc == 2 && canhoes[i].contador <= 90) { // cima //
        canhoes[i].movimento -= canhoes[i].velocidade;
        canhoes[i].rProjetil.x = canhoes[i].x - rRcam.x;
        canhoes[i].rProjetil.y = canhoes[i].y - rRcam.y + canhoes[i].movimento;
        canhoes[i].contador++;
      }
      else if(canhoes[i].sentidoc == 3 && canhoes[i].contador <= 90) { // baixo //
        canhoes[i].movimento += canhoes[i].velocidade;
        canhoes[i].rProjetil.x = canhoes[i].x - rRcam.x;
        canhoes[i].rProjetil.y = canhoes[i].y - rRcam.y + canhoes[i].movimento;
        canhoes[i].contador++;
      }
      if(canhoes[i].contador > 90) {
        canhoes[i].rProjetil.x = canhoes[i].x - rRcam.x; 
        canhoes[i].rProjetil.y =  canhoes[i].y - rRcam.y;
        canhoes[i].contador++;
      }
    }
    else if(canhoes[i].contador >= canhoes[i].espera) {
      canhoes[i].rProjetil.x = canhoes[i].x + 12 - rRcam.x; 
      canhoes[i].rProjetil.y =  canhoes[i].y + 10 - rRcam.y;
      canhoes[i].contador = 0;
      canhoes[i].movimento = 0;
    }
  }
  //vendo a colisao dessa bosta//
  player_canhao();
  //renderizar bombinha maluca//
  for(int i = 0; i < numCanhoes; i++) {
   SDL_RenderCopy(render, cannonTex, &sProjetilc, &canhoes[i].rProjetil);
  }
  //renderizar canhao de vdd//
  for(int i = 0; i < numCanhoes; i++) {
   //SDL_RenderCopy(render, cannonTex, &canhoes[i].sCanhao, &canhoes[i].rCanhao);
  }
}
void player_canhao(void) {
  static int damagec = -1;
  static int counter = 0;
  for(int i = 0; i < numCanhoes && invencible == 0; i++) { 
    colisao = collision(rR, canhoes[i].rProjetil, 0, 0);
    if(colisao) {
      //printf("colidiu!\n");
      Mix_PlayChannel(4, damage, 0);
      //kback = mob(i, colisao, rR);
      if(canhoes[i].sentidoc == 0) {
        damagec = 0;
        counter = 1;
      }
      //quando terminar o kback arrumar isso aq !
      if(life >= 0 && invencible == 0) {
        life--;
        invencible = 1;
      } 
    }
    if(canhoes[i].sentidoc == 0 && damagec == 0 && canhoes[i].contador <= 90) {
      colisao = false;
      for(int i = 0; i < numWall && !colisao; i++) {  //COLIDINDO COM WALL//
        colisao = collision(rR, rRw[i], vel, 0);
      }
      if(!colisao)
        gX += canhoes[i].velocidade;
    }
    if(canhoes[i].contador > 90) {
      damagec = -1;
    }
  } 
}
bool janela (void) {
  bool success = true;
  // START //
  if(SDL_Init(SDL_INIT_VIDEO) < 0) {
    printf("Ocorreu um imprevisto! :(, %s\n", SDL_GetError());
      success = false;
      // A TELA NÃO INICIOU //
  }
  else {
    printf("[Console]SDL iniciado!\n");
    SDL_Delay(100);
    //VARIAVEIS//
    gJanela = SDL_CreateWindow("Dave, The Wizard!", SDL_WINDOWPOS_CENTERED,SDL_WINDOWPOS_CENTERED, w,h, SDL_WINDOW_RESIZABLE);
      if(gJanela == NULL) {
          printf("Ocorreu um imprevisto! :(, %s\n", SDL_GetError()); 
            success = false;
        }
      else{
          render = SDL_CreateRenderer(gJanela, -1, 0);
          SDL_SetRenderDrawColor(render, 0, 0, 0, 255);
        }
  }
  //FIM//
  return success;
}
bool rescalar(void){
   if(event.type ==SDL_WINDOWEVENT)
      if(event.type ==SDL_WINDOWEVENT_RESIZED)
      {
        w=event.window.data1;
        h=event.window.data2;
    }
}
                                                                                              //MOVIMENTOS E RENDER//
void movements (void) {
  // RECONHECER MOVIMENTOS //
  //event.type == SDL_KEYDOWN && event.key.keysym.sym == SDLK_LALT // 
  if(event.type == SDL_KEYDOWN) { // Pressionando as teclas //
    if(event.key.keysym.sym == SDLK_a) {
        xe = -1;
        sentido = 'e';
    }
    if(event.key.keysym.sym == SDLK_d) {
        xd = 1;
        sentido = 'd';
    }
    if(event.key.keysym.sym == SDLK_w) {
        yc = -1;
        sentido = 'c';
    }
    if(event.key.keysym.sym == SDLK_s) {
        yb = 1;
        sentido = 'b';
    }
    if(event.key.keysym.sym == SDLK_q && !regeneffect) {
        regeneffect = true;
    }
    //interagir//
    if(event.key.keysym.sym == SDLK_e) {
      interagir = true;
    }
  }

  else if(event.type == SDL_KEYUP) { // Despressionando as teclas //
    if(event.key.keysym.sym == SDLK_a)
        xe = 0;
    if(event.key.keysym.sym == SDLK_d)
        xd = 0;
    if(event.key.keysym.sym == SDLK_w)
        yc = 0;
    if(event.key.keysym.sym == SDLK_s)
        yb = 0; 
    if(event.key.keysym.sym == SDLK_q) {
        regeneffect = false;
        regeneffectkeydown = false;
    }
    if(event.key.keysym.sym == SDLK_e) {
      interagir = false;
    }
  }
}

void mousemovements(void) {
  if(event.type == SDL_MOUSEBUTTONDOWN && !projetil) {
      if(event.button.button == SDL_BUTTON_LEFT) {
        projetil = true;
      }
  }
  if(event.type == SDL_MOUSEBUTTONUP) {
      if(event.button.button == SDL_BUTTON_LEFT) {
        projetil = false;
      }


  }
}
void makemovements(void) {
  // DANDO MOVIMENTOS //
  if(!kback.emKBACK) {  
    if(xd == 1) { // Direita //
      //colisao com paredes//
      for(int i = 0; i < numWall && !colisao; i++) { //COLIDINDO COM WALL//
        colisao = collision(rR, rRw[i], vel, 0);
      }
      //colisao com portas//
      if(!colisao)
          gX += vel;
      colisao = false;
    }
    if(xe == -1) { // ESQUERDA //
      for(int i = 0; i < numWall && !colisao; i++) { //COLIDINDO COM WALL//
        colisao = collision(rR, rRw[i], -vel, 0);
      }
      if(!colisao)
          gX -= vel;
      colisao = false;
    }
    if(yb == 1) { //  BAIXO //
      for(int i = 0; i < numWall && !colisao; i++) { //COLIDINDO COM WALL//
        colisao = collision(rR, rRw[i], 0, vel);
      }
      if(!colisao)
          gY += vel;
      colisao = false;
    }
    if(yc == -1) { // CIMA //
      for(int i = 0; i < numWall && !colisao; i++) { //COLIDINDO COM WALL//
        colisao = collision(rR, rRw[i], 0, -vel);
      }
      if(!colisao)
          gY -= vel;
      colisao = false; 
    }
  }
}
bool collision(SDL_Rect r1, SDL_Rect r2, int velocidadex, int velocidadey) {
  r1.x += velocidadex;
  r1.y += velocidadey;
  if( r1.x + r1.w > r2.x && r2.x + r2.w > r1.x &&
    r1.y + r1.h > r2.y && r2.y + r2.h > r1.y) {
    return true;
  }
  return false;
}

bool renderizar(void) {
  static SDL_RendererFlip flip = SDL_FLIP_HORIZONTAL;
  static SDL_RendererFlip flipv = SDL_FLIP_VERTICAL;
  static const int framemaximumexplosion = 18;
  //RECT CAMERA//
   if(rRcam.x < 0) {
    rRcam.x = 0;
  }
  if(rRcam.y < 0){
    rRcam.y = 0;
  }
  if(rRcam.x + rRcam.w >= mapw) {
    rRcam.x = mapw - 640;
  }
  if(rRcam.y + rRcam.h >= maph) {
    rRcam.y = maph - 400;
  } 
  // HUD configs //
      //heart//
  SDL_Rect sH = {0,11 * life,43,11};
  rH.x = 10; rH.y = 10; rH.w = 86 ;rH.h = 22;
  
  //RECT do Wall//
  SDL_Rect sRw = {0,0,32,32};
  renderizarparedes();
  //Renderizar mapas e acoes//
  SDL_RenderClear(render);
  //MAPA//
  SDL_RenderCopy(render, mapTex, &rRcam, NULL);
  //objetos//
  //rect dos objetos//
  //cajado//
  if(!cajado) {
    riconCajado.x = 1105 - rRcam.x; riconCajado.y = 287 - rRcam.y; riconCajado.w = 16; riconCajado.h = 16;
    SDL_RenderCopy(render, objectTex, &siconCajado, &riconCajado); 
  }
  //RENDER DO WALL//
  for(int i = 0; i < numWall; i++)
    SDL_RenderCopy(render, wallTex, &sRw, &rRw[i]);

  // CAJADOZADA //
  if(cajado) {
    static double angle;
    cajadoAnimated(&rR, &centerstaff, &mouse, gJanela, &angle);
    //centerstaff.x = gX;
    //centerstaff.y = gY;
    angle += 90;
    staff.rR.w = 8 * 1.5;
    staff.rR.h = 30 * 1.5;
    staff.rR.x = rR.x + rR.w/2;
    staff.rR.y = rR.y + rR.h/2;
    SDL_RenderCopyEx(render, cajadoTex, &staff.sR, &staff.rR, angle, &centerstaff, flipv);
    //SDL_RenderCopy(render, cajadoTex, &staff.sR, &staff.rR);
  }


  //MOVIMENT DO PLAYER//
  playerAnimated(&rR, &sR, &rRcam, &gX, &gY, gJanela, &mouse);

  //projetil de magia//
  if(!projetilstop)
    SDL_RenderCopy(render, mageTex, &mage[0].sRp, &rProjetil);
  //MOVIMENT DO PLAYER//
  if(invencible > 0) {
    playerAnimatedDamage(&invencible, playerTex);
  }
  else {
    SDL_SetTextureAlphaMod(playerTex, 255);
  }

  if(mouse.x <= rR.x + (rR.w/2)) {
      SDL_RenderCopyEx(render, playerTex, &sR, &rR, 0, NULL, flip);
  }
  else {
    SDL_RenderCopy(render, playerTex, &sR, &rR);
  }


  //blocksinteractive();
  //canhoes//
    //renderizarCanhoes();
  //renderizar baus//
  renderizarBaus();
  // meat //
  for(int j = 0; j < meatboxMobs; j++) {
    // se ele ta com -1 significa que eu vou explodir ele //
    if(meatbox[j].life == -1 && meatbox[j].morrer == 0) {
      //printf("CAIAQ\n");
      explosionMobs(&meatbox[j].x, &meatbox[j].y, &meatbox[j].rR, &explodir, &rRcam);
      explodir.sR.x = 0; explodir.sR.x = 0; 
      explodir.sR.w = 32; explodir.sR.h = 32;
      meatbox[j].morrer += meatbox[j].morrer + 1;
      SDL_RenderCopy(render, explodirTex, &explodir.sR, &explodir.rR);
      Mix_PlayChannel(6, killenemys, 0);
    }
    else if(meatbox[j].life == -1 && meatbox[j].morrer <= framemaximumexplosion) {
      //printf("-TOAQ %i\n", meatbox[j].morrer);
      animarexplosaodeMob(&meatbox[j].morrer, &explodir, rRcam);
      explodir.rR.x = explodir.x - rRcam.x;
      explodir.rR.y = explodir.y - rRcam.y;
      SDL_RenderCopy(render, explodirTex, &explodir.sR, &explodir.rR);
    }
    if(meatbox[j].life == -1 && meatbox[j].morrer > framemaximumexplosion)
      meatbox[j].life--;
    // isolando esse arrumbado //
    if(meatbox[j].life < 0) {
      meatbox[j].x = -800;
      meatbox[j].y = -800;
    }
    meatboxAnimated(&meatbox[j], &rRcam);
    if(meatbox[j].dir)
      SDL_RenderCopy(render, meatboxTex, &meatbox[j].sR, &meatbox[j].rR);
    else {
      SDL_RenderCopyEx(render, meatboxTex, &meatbox[j].sR, &meatbox[j].rR, 0, NULL, flip);
    }
  }
  // animar o ogro //
  for(int j = 0; j < ogreMobs; j++) {
     if(ogre[j].life == -1 && ogre[j].morrer == 0) {
      //printf("CAIAQ\n");
      explosionMobs(&ogre[j].x, &ogre[j].y, &ogre[j].rR, &explodir, &rRcam);
      explodir.sR.x = 0; explodir.sR.x = 0; 
      explodir.sR.w = 32; explodir.sR.h = 32;
      ogre[j].morrer += ogre[j].morrer + 1;
      SDL_RenderCopy(render, explodirTex, &explodir.sR, &explodir.rR);
      Mix_PlayChannel(6, killenemys, 0);
    }
    else if(ogre[j].life == -1 && ogre[j].morrer <= framemaximumexplosion) {
      //printf("-TOAQ %i\n", meatbox[j].morrer);
      animarexplosaodeMob(&ogre[j].morrer, &explodir, rRcam);
      explodir.rR.x = explodir.x - rRcam.x;
      explodir.rR.y = explodir.y - rRcam.y;
      SDL_RenderCopy(render, explodirTex, &explodir.sR, &explodir.rR);
    }
    if(ogre[j].life == -1 && ogre[j].morrer > framemaximumexplosion)
      ogre[j].life--;
    // isolando esse arrumbado //
    if(ogre[j].life < 0) {
      ogre[j].x = -800;
      ogre[j].y = -800;
    }
    //JOGAR PRA LONGE //
    ogreAnimated(&ogre[j], &rRcam);

    if(ogre[j].dir)
      SDL_RenderCopy(render, ogreTex, &ogre[j].sR, &ogre[j].rR);
    else {
      SDL_RenderCopyEx(render, ogreTex, &ogre[j].sR, &ogre[j].rR, 0, NULL, flip);
    }
  }
  // MAGE //
  for(int i = 0; i < mageMobs; i++) {
      if(mage[i].life == -1 && mage[i].morrer == 0) {
      //printf("CAIAQ\n");
      explosionMobs(&mage[i].x, &mage[i].y, &mage[i].rR, &explodir, &rRcam);
      explodir.sR.x = 0; explodir.sR.x = 0; 
      explodir.sR.w = 32; explodir.sR.h = 32;
      mage[i].morrer += mage[i].morrer + 1;
      SDL_RenderCopy(render, explodirTex, &explodir.sR, &explodir.rR);
      Mix_PlayChannel(6, killenemys, 0);
    }
    else if(mage[i].life == -1 && mage[i].morrer <= framemaximumexplosion) {
      //printf("-TOAQ %i\n", meatbox[j].morrer);
      animarexplosaodeMob(&mage[i].morrer, &explodir, rRcam);
      explodir.rR.x = explodir.x - rRcam.x;
      explodir.rR.y = explodir.y - rRcam.y;
      SDL_RenderCopy(render, explodirTex, &explodir.sR, &explodir.rR);
    }
    if(mage[i].life == -1 && mage[i].morrer > framemaximumexplosion)
      mage[i].life--;
    // isolando esse arrumbado //
    if(mage[i].life < 0) {
      mage[i].x = -800;
      mage[i].y = -800;
    }



    mageAnimated(&mage[i], &rRcam);
    SDL_RenderCopy(render, mageTex, &mage[i].sRp, &mage[i].rRp);

    if(mage[i].dir)
       SDL_RenderCopy(render, mageTex, &mage[i].sR, &mage[i].rR);
    else {
      SDL_RenderCopyEx(render, mageTex, &mage[i].sR, &mage[i].rR, 0, NULL, flip);
    }
  }
  for(int i=0; i < cristalQuantidade; i++) {
    cristalAnimated(&cristal[i], cristalTex, rRcam);
    SDL_RenderCopy(render, cristalTex, &cristal[i].sR, &cristal[i].rR);
  }
  //iluminação e tal//
   SDL_RenderCopy(render, mapTex2, &rRcam, NULL);

  if(portao.contador < 96) {
    SDL_RenderCopy(render, portaoTex, &portao.sR, &portao.rR);
  }
            //HUD//
  SDL_RenderCopy(render, heartTex, &sH, &rH);
  //renderizarMiniBoss();
  if(cajado) {
    SDL_RenderCopy(render, HUDTex, &sProjetilPoder, &rProjetilPoder);
  }
  SDL_RenderCopy(render, HUDTex, &siconPotion, &riconPotion);
  //potion//
  SDL_RenderCopy(render, text[0], NULL, &textRect);
}
void renderizarBaus(void) {
  for(int i = 0; i < numChest; i++) {
    // atualizando status do rect//
    chest[i].pos.x = chest[i].x - rRcam.x; chest[i].pos.y = chest[i].y - rRcam.y;
    if(chest[i].estado)
      SDL_RenderCopy(render, chestTex, &sChestF, &chest[i].pos);
    else if(!chest[i].estado)
      SDL_RenderCopy(render, chestTex, &sChestA, &chest[i].pos);
  }
}
void renderizarparedes(void) {
  rRw[0].x = -4 - rRcam.x; rRw[0].y = 2 - rRcam.y; rRw[0].w = 364; rRw[0].h = 1210; //SPACE DIREITA-- //
  rRw[1].x = 359 - rRcam.x; rRw[1].y = 459 - rRcam.y; rRw[1].w = 96; rRw[1].h = 120; // TORRE CASTELO DIREITA CIMA //
  rRw[2].x = 360 - rRcam.x; rRw[2].y = 572 - rRcam.y; rRw[2].w = 72; rRw[2].h = 318; // WALL //
  rRw[3].x = 359 - rRcam.x; rRw[3].y = 886 - rRcam.y; rRw[3].w = 99; rRw[3].h = 167; // WALL BAIXO  = SALA 1//
  rRw[4].x = 453 - rRcam.x; rRw[4].y = 909 - rRcam.y; rRw[4].w = 751; rRw[4].h = 126; // WALL // 
  rRw[5].x = 768 - rRcam.x; rRw[5].y = 887 - rRcam.y; rRw[5].w = 96; rRw[5].h = 166; // WALL //  
  rRw[6].x = 1199 - rRcam.x; rRw[6].y = 888 - rRcam.y; rRw[6].w = 98; rRw[6].h = 165; // WALL //  
  rRw[7].x = 1224 - rRcam.x; rRw[7].y = 499 - rRcam.y; rRw[7].w = 49; rRw[7].h = 438; // wALL //  
  rRw[8].x = 1201 - rRcam.x; rRw[8].y = 385 - rRcam.y; rRw[8].w = 95; rRw[8].h = 132; // WALL //  
  rRw[9].x = 1122 - rRcam.x; rRw[9].y = 380 - rRcam.y; rRw[9].w = 80; rRw[9].h = 140; // UAU //  
  rRw[10].x = 1057 - rRcam.x; rRw[10].y = 407 - rRcam.y; rRw[10].w = 90; rRw[10].h = 110; // WALL WALL // 
  rRw[11].x = 815 - rRcam.x; rRw[11].y = 519 - rRcam.y; rRw[11].w = 242; rRw[11].h = 33; // UAU WALL // 
  rRw[12].x = 733 - rRcam.x; rRw[12].y = 516 - rRcam.y; rRw[12].w = 83; rRw[12].h = 30; // TORRE //
  rRw[13].x = 600 - rRcam.x; rRw[13].y = 519 - rRcam.y; rRw[13].w = 83; rRw[13].h = 30; // TORRE // 
  rRw[14].x = 455 - rRcam.x; rRw[14].y = 519 - rRcam.y; rRw[14].w = 216; rRw[14].h = 33; // TORRE // 
  rRw[15].x = 1191 - rRcam.x; rRw[15].y = 309 - rRcam.y; rRw[15].w = 104; rRw[15].h = 84; // PAREDE // 
  rRw[16].x = 1247 - rRcam.x; rRw[16].y = 44 - rRcam.y; rRw[16].w = 109; rRw[16].h = 204; // PAREDE //
  rRw[17].x = 1267 - rRcam.x; rRw[17].y = 234 - rRcam.y; rRw[17].w = 91; rRw[17].h = 76; // PAREDE//
  rRw[18].x = 359 - rRcam.x; rRw[18].y = 3 - rRcam.y; rRw[18].w = 978; rRw[18].h = 45; // caixotes = sala 2//
  //intervalo//
  rRw[25].x = 457 - rRcam.x; rRw[25].y = 3 - rRcam.y; rRw[25].w = 71; rRw[25].h = 139; //sala 2 da dg - agua//
  rRw[26].x = 473 - rRcam.x; rRw[26].y = 280 - rRcam.y; rRw[26].w = 55; rRw[26].h = 56; //sala 2 da dg - agua//
  rRw[27].x = 460 - rRcam.x; rRw[27].y = 330 - rRcam.y; rRw[27].w = 20; rRw[27].h = 52; //sala 2 da dg - agua//
  rRw[28].x = 408 - rRcam.x; rRw[28].y = 215 - rRcam.y; rRw[28].w = 8; rRw[28].h = 154; //sala 2 da dg - agua//
  rRw[29].x = 408 - rRcam.x; rRw[29].y = 215 - rRcam.y; rRw[29].w = 119; rRw[29].h = 7; //sala 2 da dg - agua//
  rRw[19].x = 408 - rRcam.x; rRw[19].y = 215 - rRcam.y; rRw[19].w = 119; rRw[19].h = 7; //sala 2 da dg - agua// 
  rRw[20].x = 519 - rRcam.x; rRw[20].y = 215 - rRcam.y; rRw[20].w = 8; rRw[20].h = 69; //sala 2 da dg - agua//
  rRw[21].x = 913 - rRcam.x; rRw[21].y = 9 - rRcam.y; rRw[21].w = 71; rRw[21].h = 120; //sala 2 da dg - agua//
  rRw[22].x = 914 - rRcam.x; rRw[22].y = 113 - rRcam.y; rRw[22].w = 332; rRw[22].h = 20; //sala 2 da dg - agua//
  rRw[23].x = 914 - rRcam.x; rRw[23].y = 113 - rRcam.y; rRw[23].w = 101; rRw[23].h = 44; //sala 2 da dg - agua//
  rRw[24].x = 769 - rRcam.x; rRw[24].y = 165 - rRcam.y; rRw[24].w = 10; rRw[24].h = 134; //sala 2 da dg - agua//
  rRw[25].x = 769 -rRcam.x; rRw[25].y = 165 -rRcam.y; rRw[25].w = 114; rRw[25].h = 14; //bau da primeira parte//
  rRw[26].x = 878 -rRcam.x; rRw[26].y = 165 -rRcam.y; rRw[26].w = 10; rRw[26].h = 138; //bau da primeira parte//

  //portao //
  if(portao.contador < 96) {
    rRw[28].x = portao.x -rRcam.x; rRw[28].y = portao.y -rRcam.y; rRw[28].w = 48 * 1.5; rRw[28].h = 48 * 1.5; //bau da primeira parte//
  }
  else {
    rRw[28].x = -500 -rRcam.x; rRw[28].y = -500 -rRcam.y; rRw[28].w = 48 * 1.5; rRw[28].h = 48 * 1.5; //bau da primeira parte//
  }
  //rRw[29].x = 765 -rRcam.x; rRw[29].y = 281 -rRcam.y; rRw[29].w = 27; rRw[29].h = 26; //bau da primeira parte//


  rRw[30].x = 456 -rRcam.x; rRw[30].y = 8 -rRcam.y; rRw[30].w = 72; rRw[30].h = 100; //bau da primeira parte//
  rRw[31].x = 473 -rRcam.x; rRw[31].y = 279 -rRcam.y; rRw[31].w = 56; rRw[31].h = 58; //bau da primeira parte//
  rRw[32].x = 406 -rRcam.x; rRw[32].y = 218 -rRcam.y; rRw[32].w = 12; rRw[32].h = 156; //bau da primeira parte//
  rRw[33].x = 406 -rRcam.x; rRw[33].y = 324 -rRcam.y; rRw[33].w = 20; rRw[33].h = 60; //bau da primeira parte//
  rRw[34].x = 1702 -rRcam.x; rRw[34].y = 209 -rRcam.y; rRw[34].w = 176; rRw[34].h = 53; //bau da primeira parte//
  rRw[35].x = 1060 -rRcam.x; rRw[35].y = 254 -rRcam.y; rRw[35].w = 21; rRw[35].h = 53; //bau da primeira parte//
  rRw[36].x = 1008 -rRcam.x; rRw[36].y = 254 -rRcam.y; rRw[36].w = 20; rRw[36].h = 53; //bau da primeira parte//
  rRw[37].x = 1075 -rRcam.x; rRw[37].y = 207 -rRcam.y; rRw[37].w = 189; rRw[37].h = 30; //bau da primeira parte//
  rRw[38].x = 1007 -rRcam.x; rRw[38].y = 157 -rRcam.y; rRw[38].w = 11; rRw[38].h = 144; //bau da primeira parte//
  rRw[39].x = 479 -rRcam.x; rRw[39].y = 562 -rRcam.y; rRw[39].w = 10; rRw[39].h = 153; //bau da primeira parte//
  rRw[40].x = 479 -rRcam.x; rRw[40].y = 686 -rRcam.y; rRw[40].w = 24; rRw[40].h = 29; //bau da primeira parte//
  rRw[41].x = 532 -rRcam.x; rRw[41].y = 607 -rRcam.y; rRw[41].w = 24; rRw[41].h = 48; // CRISTAIS //
  rRw[42].x = 1033 -rRcam.x; rRw[42].y = 173 -rRcam.y; rRw[42].w = 24; rRw[42].h = 48; // CRISTAIS//
  rRw[43].x = 820 -rRcam.x; rRw[43].y = 183 -rRcam.y; rRw[43].w = 24; rRw[43].h = 48; // CRISTAIS//
  rRw[44].x = 480 -rRcam.x; rRw[44].y = 202 -rRcam.y; rRw[44].w = 24; rRw[44].h = 48; // CRISTAIS//
  rRw[45].x = 590 -rRcam.x; rRw[45].y = 574 -rRcam.y; rRw[45].w = 11; rRw[45].h = 92; // DFGGSF//
  rRw[46].x = 684 -rRcam.x; rRw[46].y = 136 -rRcam.y; rRw[46].w = 48; rRw[46].h = 28; // DFGGSF//
  

  // cristal[0].x = 532; cristal[0].y = 607 // cristal[1].x = 1033; cristal[1].y = 173
  // cristal[2].x = 820; cristal[2].y = 183 // cristal[3].x = 480; cristal[3].y = 202
}
void invencibleF (void) {
  //INVENCIBILIDADE DO JOGADOR APOS A COLISAO COM MOB//
  if(invencible == 1) {
    Mix_PlayChannel(4, damage, 0);
    printf("[Console]Tempo de Invencibilidade Iniciado! %i Vidas!\n", life);
    invencible++;
  }
  else if(invencible > 1 && invencible <= 40) {
    invencible++;
  }
  else if(invencible > 40) {
    invencible = 0; 
    printf("[Console]Tempo de Invencibilidade Finalizado!\n");
  }
}
                                                                                                  //CAMERA E IDENTIFICACAO DE SALAS//

void salaAtual()
{
  if(gX >= 0 && gX+rR.w <= 14400 && gY >= 0 && gY+rR.h <= 1200) {
    sala = 1;//primeira sala
    if(checkSala != sala) {
      renderizar();
      teladeAnimacaoOUT();
      salaCamera();
      teladeAnimacaoIN();
    }
    checkSala = sala;
  }
}
void salaCamera()
{
  if(sala==1)
  {
    rRcam.x = gX - 320;
    rRcam.y = gY - 200;
    if(rRcam.x > 1120)
    {
      rRcam.x = 1120;
    }
    if(rRcam.y > 980)
    {
      rRcam.y = 980;
    }
  }
}
void teladeAnimacaoOUT (void) {
  for(fadeAlpha = 0; fadeAlpha <= 255; fadeAlpha+=5) {
    renderizar();
    SDL_SetTextureAlphaMod(fadeTex, fadeAlpha);
    SDL_RenderCopy(render, fadeTex, NULL, NULL);
    SDL_RenderPresent(render);
    SDL_Delay(7);
  }
}
void teladeAnimacaoIN (void) {
  for(fadeAlpha = 255; fadeAlpha >= 0; fadeAlpha-=5) {
    renderizar();
    SDL_SetTextureAlphaMod(fadeTex, fadeAlpha);
    SDL_RenderCopy(render, fadeTex, NULL, NULL);
    SDL_RenderPresent(render);
    SDL_Delay(7);
  }
  fadeAlpha=0;
}
void projetilF (void) {
  static int contador = 0;
  static bool colisao = false;
  static bool stop = false;
  static int velprojetil;
  static char sentidop = 'n';
  
  projetilstop = stop;
  wizard_Magic(&projetil, &cajado, &mouse, &rR, &rProjetil, &rRcam, gJanela, &projetilstop, contador);
  if(projetil && contador == 0 && !stop) {
    contador = 1;
  }
  if(contador == 1 && !stop && projetil && cajado) { //som do projetil//
    Mix_PlayChannel(3, projetilstart, 0);
  }
  if(contador > 0 && contador <= 45 && !colisao && !stop) {
      contador++;
  }
  if(contador > 45) {
    stop = true;
  }
  if(contador > 0 && contador <= DELAY_PROJETIL && stop) {
    contador++;
    rProjetil.x = -2000 - rRcam.x;
    rProjetil.y = -2000 - rRcam.y;
  }
  else if(contador > DELAY_PROJETIL) {
    stop = false;
    contador = 0;
  }
  colisao = false;
  //COLISAO DE PROJETIL COM PAREDE//
  for(int i = 0; i < numWall; i++) { 
    colisao = collision(rProjetil, rRw[i], 0, 0);
    if(colisao) {
      printf("[Console]O projetil colidiu com a parede %i\n", i); 
      stop = true;        
    }
  }
  // COLISAO DE PROJETIL COM MOBS //
  colisao = false;
  for(int i = 0; i < meatboxMobs; i++) { 
      if(meatbox[i].life >= 0) { 
          colisao = collision(rProjetil, meatbox[i].rR, 0, 0);
          MAGIC_MEATBOX(rProjetil, meatbox[i].rR, &meatbox[i], &coins);
        if(colisao) {
          Mix_PlayChannel(3, projetilhit, 0);
          stop = true;
        }
      }
  }
  colisao = false; 
  for(int i = 0; i < ogreMobs; i++) { 
    if(ogre[i].life >= 0) { 
        colisao = collision(rProjetil, ogre[i].rR, 0, 0);
        MAGIC_OGRE(rProjetil, ogre[i].rR, &ogre[i], &coins);
      if(colisao) {
        Mix_PlayChannel(3, projetilhit, 0);
        stop = true;
      }
    }
  } 
  colisao = false; 
  for(int i = 0; i < mageMobs && !colisao && !stop; i++) { 
    if(mage[i].life >= 0) { 
        colisao = collision(rProjetil, mage[i].rR, 0, 0);
        MAGIC_MAGE(rProjetil, mage[i].rR, &mage[i], &coins);
      if(colisao) {
        Mix_PlayChannel(3, projetilhit, 0);
        stop = true;
      }
    }
  } 
}
bool wall_agua(int i) {
  if(i >= 19 && i <= 24)
    return false;
  else
    return true;
}
void blocksinteractive(void) {  
    bool dir = false, esq = false, cim = false, baix = false;
    bool cdir = false, cesq = false, ccim = false, cbaix = false, c = false;
  //empurrar//
    if(!interagir) {
      for(int i = 0; i < numWall && !dir; i++) {
        dir =  collision(rCaixa[0], rRw[i], vel, 0);
        cdir =  collision(rR, rCaixa[0], vel, 0);
      }
      for(int i = 0; i < numWall && !esq; i++) {
        esq =  collision(rCaixa[0], rRw[i], -vel, 0);
        cesq =  collision(rR, rCaixa[0], -vel, 0);
      }
      for(int i = 0; i < numWall && !cim; i++) {
        cim =  collision(rCaixa[0], rRw[i], 0, -vel);
        ccim =  collision(rR, rCaixa[0], 0, -vel);
      }
      for(int i = 0; i < numWall && !baix; i++) {
        baix =  collision(rCaixa[0], rRw[i], 0, vel);
        cbaix =  collision(rR, rCaixa[0], 0, vel);
      }
        if(cdir /*&& sentido == 'd'*/ && !dir && !c)
            caixax[0] += vel;
        if(cesq /*&& sentido == 'e'*/ && !esq && !c)
            caixax[0] -= vel;
        if(cbaix /*&& sentido == 'b'*/  && !baix && !c)
            caixay[0] += vel;
        if(ccim /*&& sentido == 'c'*/  && !cim && !c)
            caixay[0] -= vel;
      }
      //puxar//
      if(interagir) {
      for(int i = 0; i < numWall && !dir; i++) {
        dir =  collision(rCaixa[0], rRw[i], vel, 0);
        cdir =  collision(rR, rCaixa[0], vel, 0);
      }
      for(int i = 0; i < numWall && !esq; i++) {
        esq =  collision(rCaixa[0], rRw[i], -vel, 0);
        cesq =  collision(rR, rCaixa[0], -vel, 0);
      }
      for(int i = 0; i < numWall && !cim; i++) {
        cim =  collision(rCaixa[0], rRw[i], 0, -vel);
        ccim =  collision(rR, rCaixa[0], 0, -vel);
      }
      for(int i = 0; i < numWall && !baix; i++) {
        baix =  collision(rCaixa[0], rRw[i], 0, vel);
        cbaix =  collision(rR, rCaixa[0], 0, vel);
      }

    if(cdir /*&& sentido == 'd'*/ && !dir && !c)
        caixax[0] -= vel;
    if(cesq /*&& sentido == 'e'*/ && !esq && !c)
        caixax[0] += vel;
    if(cbaix /*&& sentido == 'b'*/  && !baix && !c)
        caixay[0] -= vel;
    if(ccim /*&& sentido == 'c'*/  && !cim && !c)
        caixay[0] += vel;
    }
  verificator();
  //renderizando//
  //caixotes topirescos lindos//
  rCaixa[0].x = caixax[0] - rRcam.x; rCaixa[0].y = caixay[0] - rRcam.y; rCaixa[0].w = 16; rCaixa[0].h = 24;
  SDL_RenderCopy(render, interactiveTex, &sCaixa[0], &rCaixa[0]);
  //portas merdas pra atrapalhar a vida//
  if(porta[0])
    rPorta[0].x = 896 - rRcam.x; rPorta[0].y = 165 - rRcam.y; rPorta[0].w = 22.5; rPorta[0].h = 18;
    SDL_RenderCopy(render, interactiveTex, &sPorta[0], &rPorta[0]);
}
void verificator(void) {
  if((rCaixa[0].x >= 770 - rRcam.x && rCaixa[0].x <= 776 + 18 - rRcam.x) 
    && (rCaixa[0].y >= 198 - rRcam.y && rCaixa[0].y <= 198 + 24 - rRcam.y) && (porta[0])) {
      porta[0] = false;
      rPorta[0].x = -50 - rRcam.x; rPorta[0].y = -50 - rRcam.y;
      printf("[Console] A porta foi aberta!\n");
      Mix_PlayChannel(1, warning, 0);
  }

}
void regenerar(void) {
  if(regeneffect){    
    if(potion > 0 && life < LIFE-1 && !regeneffectkeydown){
      life = life+2;
      potion--;
      Mix_PlayChannel(6, regen, 0);
      printf("[Console] 1 coracao regenerado! Agora voce tem %i pocoes!\n", potion);
      regeneffectkeydown = true;
    }
    else if(potion > 0 && life == 4 && !regeneffectkeydown) {
      life = LIFE;
      potion--;
      regeneffect = false;
      Mix_PlayChannel(6, regen, 0);
      printf("[Console] meio coracao regenerado! Agora voce tem %i pocoes!\n", potion);
      regeneffectkeydown = true;
    }
    else if(potion <= 0 && !regeneffectkeydown) {
      Mix_PlayChannel(6, error, 0);
      printf("[Console] Voce nao tem pocoes!\n");
      regeneffectkeydown = true;
    }
  }
}

void interaction(void) {
  colisao = false;
  colisao = collision(rR, riconCajado, 0, 0);
  if(colisao && !cajado) {
    Mix_PlayChannel(1, interactioneffect, 0);
    cajado = true;
    riconCajado.x = -50;
    riconCajado.y = -50;
  }
  // interacao com os baus//
  //bau 1//
  if(chest[0].estado) {
    // if para verificar se houve interacao! //
    if(sqrt(pow(rR.x + rR.w - chest[0].pos.x,2) +pow(rR.y + rR.h - chest[0].pos.y,2)) <= 75) {
      chaves++;
      potion += 2;
      chest[0].estado = false;
      printf("[Console]Agora voce tem %i chaves e %i pocoes\n", chaves, potion);
      Mix_PlayChannel(1, openchest, 0);
      // se houve interacao //
      abrirDialogbox("Voce recebeu duas pocoes! Clique 'alt' para continuar!");
      interagir = false;
    }
  }
}
  void interactioncristais(CRISTAL* cristal)
  {
    //desativar cristais
    if(interagir)
    { 
      for(int i = 0; i < cristalQuantidade; i++)
      {
          if(sqrt(pow(rR.x + rR.w - cristal->rR.x,2) +pow(rR.y + rR.h - cristal->rR.y,2)) <= 100)
        {
            Mix_PlayChannel(1, cristalsounds, 0);
            cristal->ativo=false;
        }
      }
    }  
  } 

                                                                                                                      // MAIN // 
int main (void) {
  //test//
  fadeSurf = SDL_CreateRGBSurface(0, 640, 400, 32, 0, 0, 0, fadeAlpha);
  //INICIANDO SDL//
  SDL_Init(SDL_INIT_EVERYTHING);
  TTF_Init();
  Mix_OpenAudio(MIX_DEFAULT_FREQUENCY, MIX_DEFAULT_FORMAT, 2, 4096);
  Mix_Volume(1, 50);
  //START PLAYER//
  rR.x = gX; rR.y = gY; rR.w = 64; rR.h = 120;
  //FRAMETIME//
  const int FPS = 60;
  const int frameDelay = 1000/ FPS;
  int frameStart;
  int frameTime;
  //Start em Window//
  if(!janela()) {
    printf("A TELA NÃO INICIOU!");
  }
  else{
    //GAME HERE//
    fontes();
    printf("[Console] fontes carregadas!\n");
    printf("[Console]tela iniciada\n");
    surfaces();
    printf("[Console]surfaces carregadas\n");
    audio();
    printf("[Console]audio iniciado\n");
    printf("[Console]o Jogo ira iniciar...\n");
    printf(". ");
    printf(". ");
    printf(".\n");
    printf("[Console]iniciando!\n");
    Mix_PlayChannel(1, welcome, 0);
    //Mix_PlayMusic(fightmusic, -1);
    Mix_VolumeMusic(30);
    //TIRANDO O ALPHA DO WALL//
    // E88E0C
    //SDL_SetTextureColorMod( playerTex, 50, 50, 50 );
    SDL_SetTextureAlphaMod(wallTex, 0);
    //definindo o inicio da tela//
    salaAtual();
    salaCamera();
    //reescalando//
    rescalar();
    SDL_RenderSetLogicalSize(render, 640, 400);
    //préiniciados//
    cristalStart();
    iniciarCanhoes();
    iniciarChests();
    meatboxStart();
    ogreStart();
    mageStart();
    playerStart();

    srand(time(NULL));

    renderizar();
    teladeAnimacaoIN();
    while(gaming) {                                                                                                             //GAME LOOP//
      //FRAMES//
        frameStart = SDL_GetTicks();
      //Eventos//
      while(SDL_PollEvent(&event)){
        //X to close//
        if (event.type == SDL_QUIT)
          gaming = false;
        //reconhecendo movimentos//
        mousemovements();
        movements();
      }
      // RESCALAR JANELA E SPRITES //
      rescalar();
      SDL_RenderSetLogicalSize(render, 640, 400);

      // dando movimentos & ações//
      makemovements();
      projetilF();
      if(interagir) {
        //printf("[Console]Vamos tentar achar um objeto para voce!\n");
        interaction();
      }
      regenerar();
      alterarfonte(0);
      //camera//
        //camera e sala//
      salaAtual();
      salaCamera();
      // movimentos dos mobs //
      for(int i = 0; i < meatboxMobs; i++) {
        kback.mobNUMEROtemp = i;
        meatboxEngine(&meatbox[i], &rR, rRw, numWall, &life, &invencible, &kback);
      }
      for(int i = 0; i < ogreMobs; i++) {
        kback.mobNUMEROtemp = i;
        ogreEngine (&ogre[i], &rR, rRw, numWall, &life, &invencible, &kback);
      }
      for(int i = 0; i < mageMobs; i++) {
        mageEngine (&mage[i], &rRcam, &rR, &life, &invencible, rRw, numWall);
      }
      for(int i=0; i < cristalQuantidade ;i++)
      {
        interactioncristais(&cristal[i]);
      }
      //printf("%d",cristal[0].ativo);
      invencibleF();
      //KNOCKBACK//
      if(kback.mobTYPE == 'M')
      {
        takeKnockback (&kback, rR, meatbox[kback.mobNUMERO].rR, &gX, &gY, vel, rRw, numWall);
      }
      else if(kback.mobTYPE == 'O')
      {
        takeKnockback (&kback, rR, ogre[kback.mobNUMERO].rR, &gX, &gY, vel, rRw, numWall);
      }

      // GOD MODE //
      
      if(life < 2)
        life = LIFE;
      
      if(!cristal[0].ativo && !cristal[1].ativo && !cristal[2].ativo && !cristal[3].ativo) {
      }
      else if((!cristal[0].ativo || !cristal[1].ativo || !cristal[2].ativo || !cristal[3].ativo) && killthemall() == 1) 
      {
          missao.desafiomatarportempo = true;
          // REwIND //
          ogreStart();
          mageStart();
          meatboxStart();
          Mix_PlayChannel(1, error, 0);
      }
      if(!cristal[1].ativo && !cristal[2].ativo && !cristal[3].ativo) {
        if(portao.contador == 10) 
          Mix_PlayChannel(1, opendoor, 0);
        animarPortao(&portao, rRcam);
      }
      else {
        portao.rR.x = portao.x - rRcam.x;
        portao.rR.y = portao.y - rRcam.y;
        portao.rR.w = 48 * 1.5;
        portao.rR.h = 48 * 1.5; 

        portao.sR.y = 0; portao.sR.x = 0;
        portao.sR.w = 48; portao.sR.h = 48;
      }

      //printf("%i\n", coins);

      // APRESENTANDO AO USUARIO //
      renderizar();
      SDL_RenderPresent(render);
      //morte//
      if(life < 0 && invencible == 0) 
      {
            gaming = false;
            Mix_PlayChannel(1, death, 0);
            SDL_Delay(1000);
            printf("\n\n\n[Console]Voce Perdeu, Meu Consagrado! \n\n\n");
      }
      //FRAME DELAY//
      frameTime = SDL_GetTicks() - frameStart;
      if(frameDelay > frameTime) {
        SDL_Delay(frameDelay - frameTime);
      }
    }
    teladeAnimacaoOUT();
  }
  //Destroy//
  SDL_DestroyWindow(gJanela);
  SDL_DestroyTexture(playerTex);
  SDL_DestroyTexture(wallTex);
  SDL_DestroyTexture(mapTex);
  SDL_DestroyTexture(heartTex);
  SDL_DestroyTexture(interactiveTex);
  SDL_DestroyTexture(mapTex2);
  SDL_DestroyTexture(objectTex);
  SDL_DestroyTexture(HUDTex);
  SDL_DestroyTexture(cannonTex);
  SDL_DestroyTexture(chestTex);
  SDL_DestroyTexture(minibossTex);
  SDL_DestroyTexture(meatboxTex);
  SDL_DestroyTexture(ogreTex);
  SDL_DestroyTexture(explodirTex);
  SDL_DestroyTexture(mageTex);
  SDL_DestroyTexture(cajadoTex);
  SDL_DestroyTexture(cristalTex);
  SDL_DestroyTexture(portaoTex);
  TTF_CloseFont(fonte);
  SDL_FreeCursor(cursor);

  //FIM//
  Mix_Quit();
  SDL_Quit();
  TTF_Quit();  
  printf("[Dev's] Adeus caro amigo! Foi bom te conhecer ;')\n");
  return 0;
}